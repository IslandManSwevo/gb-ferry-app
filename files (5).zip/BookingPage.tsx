"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--steel:#1e3a5f;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}

  /* BOOKING LAYOUT */
  .booking-layout{display:grid;grid-template-columns:1fr 420px;min-height:100vh;}
  @media(max-width:900px){.booking-layout{grid-template-columns:1fr;}}
  .booking-main{padding:48px;display:flex;flex-direction:column;}
  .booking-sidebar{background:var(--deep);border-left:1px solid var(--border);padding:48px;position:sticky;top:0;height:100vh;overflow-y:auto;display:flex;flex-direction:column;}

  /* BRAND BAR */
  .brand-bar{display:flex;align-items:center;justify-content:space-between;margin-bottom:64px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .back-link{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.1em;text-transform:uppercase;transition:color 0.3s;cursor:pointer;}
  .back-link:hover{color:var(--gold);}

  /* PROGRESS */
  .progress-track{display:flex;align-items:center;gap:0;margin-bottom:64px;}
  .step-dot{width:32px;height:32px;border-radius:50%;border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:12px;color:var(--muted);flex-shrink:0;transition:all 0.4s;}
  .step-dot.active{border-color:var(--gold);color:var(--gold);background:rgba(201,168,76,0.08);}
  .step-dot.done{border-color:var(--gold);background:var(--gold);color:var(--ink);}
  .step-line{flex:1;height:1px;background:var(--border);transition:background 0.4s;}
  .step-line.done{background:var(--gold);}
  .step-label{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);text-align:center;margin-top:8px;}
  .step-label.active{color:var(--gold);}
  .progress-steps{display:flex;align-items:flex-start;gap:0;width:100%;}
  .step-col{display:flex;flex-direction:column;align-items:center;flex:1;}
  .step-col:not(:last-child){flex-direction:row;align-items:center;}

  .step-title{font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,48px);color:var(--white);margin-bottom:8px;}
  .step-title em{font-style:italic;color:var(--gold);}
  .step-subtitle{font-size:15px;color:var(--muted);line-height:1.7;margin-bottom:48px;}

  /* FORM ELEMENTS */
  .form-section{margin-bottom:40px;}
  .form-section-head{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:20px;display:block;padding-bottom:12px;border-bottom:1px solid var(--border);}
  .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
  @media(max-width:600px){.form-grid{grid-template-columns:1fr;}}
  .input-group{margin-bottom:0;}
  .input-label{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);margin-bottom:8px;display:block;}
  .input-field{width:100%;background:rgba(255,255,255,0.03);border:1px solid var(--border);padding:16px 18px;color:var(--white);font-family:'Outfit',sans-serif;font-size:14px;transition:border-color 0.3s;}
  .input-field:focus{border-color:var(--gold);outline:none;}
  .input-field::placeholder{color:rgba(232,244,248,0.2);}
  select.input-field option{background:var(--deep);}

  /* TYPE SELECTOR */
  .type-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:40px;}
  .type-card{padding:24px;border:1px solid var(--border);cursor:pointer;transition:all 0.3s;text-align:left;background:transparent;}
  .type-card:hover,.type-card.selected{border-color:var(--gold);background:rgba(201,168,76,0.06);}
  .type-card-label{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:8px;display:block;}
  .type-card-name{font-family:'Playfair Display',serif;font-size:20px;color:var(--white);margin-bottom:6px;}
  .type-card-desc{font-size:12px;color:var(--muted);line-height:1.6;}
  .type-check{width:16px;height:16px;border:1px solid var(--border);border-radius:50%;margin-bottom:16px;transition:all 0.3s;}
  .type-card.selected .type-check{background:var(--gold);border-color:var(--gold);}

  /* PAYMENT */
  .payment-methods{display:flex;gap:12px;margin-bottom:32px;}
  .payment-btn{flex:1;padding:16px;border:1px solid var(--border);background:transparent;color:var(--muted);font-family:'Outfit',sans-serif;font-size:12px;letter-spacing:0.1em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;}
  .payment-btn:hover,.payment-btn.active{border-color:var(--gold);color:var(--gold);background:rgba(201,168,76,0.06);}
  .card-icons{display:flex;gap:8px;margin-bottom:24px;}
  .card-icon-badge{padding:4px 10px;border:1px solid var(--border);font-size:11px;color:var(--muted);}

  /* NAV BUTTONS */
  .btn-next{background:var(--gold);color:var(--ink);border:none;padding:20px 48px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;margin-top:32px;}
  .btn-next:hover{background:var(--goldlt);transform:translateY(-2px);box-shadow:0 8px 24px rgba(201,168,76,0.25);}
  .btn-back{background:transparent;border:1px solid var(--border);color:var(--foam);padding:20px 48px;font-size:12px;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;margin-top:12px;}
  .btn-back:hover{border-color:var(--gold);color:var(--gold);}

  /* SIDEBAR */
  .sidebar-head{margin-bottom:40px;padding-bottom:32px;border-bottom:1px solid var(--border);}
  .sidebar-label{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:12px;display:block;}
  .sidebar-title{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);}
  .order-line{display:flex;justify-content:space-between;align-items:flex-start;padding:16px 0;border-bottom:1px solid var(--border);}
  .order-line:last-child{border-bottom:none;}
  .order-line-label{font-size:13px;color:var(--muted);}
  .order-line-value{font-size:13px;color:var(--foam);font-weight:500;text-align:right;}
  .order-total{padding-top:24px;margin-top:8px;}
  .order-total .order-line-label{font-size:14px;color:var(--foam);font-weight:500;}
  .order-total .order-line-value{font-family:'Playfair Display',serif;font-size:28px;color:var(--gold);font-weight:700;}
  .sidebar-note{margin-top:32px;padding:20px;background:rgba(201,168,76,0.06);border:1px solid rgba(201,168,76,0.15);}
  .sidebar-note p{font-size:12px;color:var(--muted);line-height:1.7;}
  .sidebar-note strong{color:var(--gold);}
  .trust-badges{display:flex;flex-direction:column;gap:10px;margin-top:32px;}
  .trust-badge{display:flex;align-items:center;gap:10px;font-size:12px;color:var(--muted);}
  .trust-icon{color:var(--gold);font-size:14px;flex-shrink:0;}
`;

const STEPS = ["Type", "Details", "Schedule", "Payment"];

const bookingTypes = [
  { label: "Marina", name: "Slip Reservation", desc: "Reserve a berth for your vessel — daily, weekly, or monthly." },
  { label: "Charter", name: "Fishing Charter", desc: "Half-day or full-day deep sea fishing with a professional crew." },
  { label: "Charter", name: "Sunset Cruise", desc: "Private or small-group sunset cruise around the harbour." },
  { label: "Experience", name: "Snorkel Tour", desc: "Guided reef snorkelling on Grand Bahama's Living Reef." },
];

export default function BookingPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [step, setStep] = useState(0);
  const [selectedType, setSelectedType] = useState<number | null>(null);
  const [payMethod, setPayMethod] = useState("card");

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".brand-bar, .progress-wrap, .step-title, .step-subtitle", {
        y: 30, opacity: 0, stagger: 0.1, duration: 1, ease: "power3.out"
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  const advanceStep = () => {
    gsap.fromTo(".step-content", { x: 30, opacity: 0 }, { x: 0, opacity: 1, duration: 0.5, ease: "power3.out" });
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };
  const backStep = () => {
    gsap.fromTo(".step-content", { x: -30, opacity: 0 }, { x: 0, opacity: 1, duration: 0.5, ease: "power3.out" });
    setStep((s) => Math.max(s - 1, 0));
  };

  const selectedName = selectedType !== null ? bookingTypes[selectedType].name : "Not selected";

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <div className="booking-layout">
        {/* MAIN */}
        <div className="booking-main">
          <div className="brand-bar">
            <div className="nav-logo">PORT LUCAYA<span>.</span></div>
            <a className="back-link" onClick={() => window.history.back()}>← Back to Marina</a>
          </div>

          {/* Progress */}
          <div className="progress-wrap" style={{ marginBottom: 64 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
              {STEPS.map((s, i) => (
                <>
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }} key={`col-${i}`}>
                    <div className={`step-dot${step === i ? " active" : ""}${step > i ? " done" : ""}`}>
                      {step > i ? "✓" : i + 1}
                    </div>
                    <span style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.12em", color: step === i ? "var(--gold)" : "var(--muted)", marginTop: 8 }}>{s}</span>
                  </div>
                  {i < STEPS.length - 1 && (
                    <div className={`step-line${step > i ? " done" : ""}`} style={{ flex: 1, height: 1, marginBottom: 24 }} key={`line-${i}`} />
                  )}
                </>
              ))}
            </div>
          </div>

          {/* STEP CONTENT */}
          <div className="step-content">
            {step === 0 && (
              <>
                <h2 className="step-title">Choose your <em>Experience</em></h2>
                <p className="step-subtitle">What would you like to book at Port Lucaya Marina?</p>
                <div className="type-grid">
                  {bookingTypes.map((t, i) => (
                    <button key={i} className={`type-card${selectedType === i ? " selected" : ""}`} onClick={() => setSelectedType(i)}>
                      <div className="type-check" />
                      <span className="type-card-label">{t.label}</span>
                      <p className="type-card-name">{t.name}</p>
                      <p className="type-card-desc">{t.desc}</p>
                    </button>
                  ))}
                </div>
                <button className="btn-next" onClick={advanceStep} disabled={selectedType === null}>Continue →</button>
              </>
            )}

            {step === 1 && (
              <>
                <h2 className="step-title">Your <em>Details</em></h2>
                <p className="step-subtitle">Tell us about yourself and your vessel.</p>
                <div className="form-section">
                  <span className="form-section-head">Guest Information</span>
                  <div className="form-grid">
                    <div className="input-group"><label className="input-label">First Name</label><input className="input-field" placeholder="James" /></div>
                    <div className="input-group"><label className="input-label">Last Name</label><input className="input-field" placeholder="Morrison" /></div>
                  </div>
                  <div style={{ marginTop: 16 }}>
                    <div className="input-group"><label className="input-label">Email Address</label><input className="input-field" type="email" placeholder="captain@vessel.com" /></div>
                  </div>
                  <div style={{ marginTop: 16 }}>
                    <div className="input-group"><label className="input-label">Phone / WhatsApp</label><input className="input-field" placeholder="+1 (242) 555-0123" /></div>
                  </div>
                </div>
                {selectedType === 0 && (
                  <div className="form-section">
                    <span className="form-section-head">Vessel Details</span>
                    <div className="form-grid">
                      <div className="input-group"><label className="input-label">Vessel Name</label><input className="input-field" placeholder="Sea Spirit" /></div>
                      <div className="input-group"><label className="input-label">LOA (ft)</label><input className="input-field" placeholder="52" /></div>
                      <div className="input-group"><label className="input-label">Draft (ft)</label><input className="input-field" placeholder="6" /></div>
                      <div className="input-group"><label className="input-label">Beam (ft)</label><input className="input-field" placeholder="18" /></div>
                    </div>
                    <div style={{ marginTop: 16 }}>
                      <div className="input-group"><label className="input-label">Flag / Registry</label>
                        <select className="input-field"><option>United States</option><option>Bahamas</option><option>Cayman Islands</option><option>BVI</option><option>Other</option></select>
                      </div>
                    </div>
                  </div>
                )}
                <div style={{ display: "flex", gap: 12, flexDirection: "column" }}>
                  <button className="btn-next" onClick={advanceStep}>Continue →</button>
                  <button className="btn-back" onClick={backStep}>← Back</button>
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <h2 className="step-title">Select your <em>Dates</em></h2>
                <p className="step-subtitle">Choose your arrival, duration, and any special requirements.</p>
                <div className="form-section">
                  <span className="form-section-head">Schedule</span>
                  <div className="form-grid">
                    <div className="input-group"><label className="input-label">Arrival Date</label><input className="input-field" type="date" /></div>
                    <div className="input-group"><label className="input-label">{selectedType === 0 ? "Departure Date" : "Party Size"}</label>
                      {selectedType === 0 ? <input className="input-field" type="date" /> : <input className="input-field" placeholder="4" type="number" min="1" max="12" />}
                    </div>
                  </div>
                  {selectedType === 0 && (
                    <div style={{ marginTop: 16 }}>
                      <div className="input-group"><label className="input-label">Shore Power Required</label>
                        <select className="input-field"><option>50 Amp</option><option>200 Amp</option><option>None</option></select>
                      </div>
                    </div>
                  )}
                </div>
                <div className="form-section">
                  <span className="form-section-head">Special Requests</span>
                  <textarea className="input-field" rows={4} placeholder="Any special requirements, dietary restrictions, accessibility needs..." style={{ resize: "none" }} />
                </div>
                <div style={{ display: "flex", gap: 12, flexDirection: "column" }}>
                  <button className="btn-next" onClick={advanceStep}>Continue →</button>
                  <button className="btn-back" onClick={backStep}>← Back</button>
                </div>
              </>
            )}

            {step === 3 && (
              <>
                <h2 className="step-title">Secure your <em>Booking</em></h2>
                <p className="step-subtitle">A 50% deposit is required to confirm. The balance is due on arrival.</p>
                <div style={{ display: "flex", gap: 12, marginBottom: 32 }}>
                  {["card", "paypal", "sand-dollar"].map((m) => (
                    <button key={m} className={`payment-btn${payMethod === m ? " active" : ""}`} onClick={() => setPayMethod(m)}>
                      {m === "card" ? "💳 Card" : m === "paypal" ? "PayPal" : "Sand Dollar"}
                    </button>
                  ))}
                </div>
                {payMethod === "card" && (
                  <div className="form-section">
                    <span className="form-section-head">Card Details</span>
                    <div className="input-group" style={{ marginBottom: 16 }}><label className="input-label">Card Number</label><input className="input-field" placeholder="4242 4242 4242 4242" /></div>
                    <div className="form-grid">
                      <div className="input-group"><label className="input-label">Expiry</label><input className="input-field" placeholder="MM / YY" /></div>
                      <div className="input-group"><label className="input-label">CVC</label><input className="input-field" placeholder="•••" /></div>
                    </div>
                    <div style={{ marginTop: 16 }}><div className="input-group"><label className="input-label">Name on Card</label><input className="input-field" placeholder="James Morrison" /></div></div>
                  </div>
                )}
                {payMethod === "paypal" && (
                  <div style={{ padding: "40px 0", textAlign: "center", border: "1px solid var(--border)", marginBottom: 24 }}>
                    <p style={{ color: "var(--muted)", fontSize: 14 }}>You will be redirected to PayPal to complete payment securely.</p>
                  </div>
                )}
                {payMethod === "sand-dollar" && (
                  <div style={{ padding: "40px 0", textAlign: "center", border: "1px solid rgba(201,168,76,0.3)", marginBottom: 24, background: "rgba(201,168,76,0.04)" }}>
                    <p style={{ color: "var(--gold)", fontSize: 14, fontFamily: "Outfit" }}>Pay with Bahamian Sand Dollar (CBDC). QR code will be presented on next screen.</p>
                  </div>
                )}
                <div style={{ display: "flex", gap: 12, flexDirection: "column" }}>
                  <button className="btn-next" onClick={() => window.location.href = "/book/confirmation"}>Confirm &amp; Pay Deposit →</button>
                  <button className="btn-back" onClick={backStep}>← Back</button>
                </div>
              </>
            )}
          </div>
        </div>

        {/* SIDEBAR */}
        <div className="booking-sidebar">
          <div className="sidebar-head">
            <span className="sidebar-label">Your Booking</span>
            <h3 className="sidebar-title">{selectedType !== null ? bookingTypes[selectedType].name : "Select an experience"}</h3>
          </div>
          <div>
            {[
              { label: "Experience", value: selectedName },
              { label: "Date", value: "—" },
              { label: "Guests", value: "—" },
              { label: "Duration", value: selectedType === 0 ? "Per night" : selectedType === 1 ? "8 hours" : selectedType === 2 ? "2 hours" : "3 hours" },
            ].map((l) => (
              <div key={l.label} className="order-line">
                <span className="order-line-label">{l.label}</span>
                <span className="order-line-value">{l.value}</span>
              </div>
            ))}
            <div className="order-line" style={{ borderTop: "1px solid var(--border)", marginTop: 8 }}>
              <span className="order-line-label" style={{ fontWeight: 500, color: "var(--foam)" }}>Deposit Due</span>
              <span className="order-line-value" style={{ fontFamily: "Playfair Display", fontSize: 28, color: "var(--gold)" }}>
                {selectedType === null ? "—" : selectedType === 0 ? "$150" : selectedType === 1 ? "$475" : selectedType === 2 ? "$60" : "$42"}
              </span>
            </div>
          </div>
          <div className="sidebar-note">
            <p><strong>50% deposit</strong> secures your booking. Full balance due on day of experience. Free cancellation up to 48 hours before.</p>
          </div>
          <div className="trust-badges">
            {["Secure SSL payment", "Instant confirmation", "Free 48h cancellation", "Official Bahamian operator"].map((b) => (
              <div key={b} className="trust-badge"><span className="trust-icon">✦</span>{b}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
