"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}

  .waiver-layout{display:grid;grid-template-columns:1fr 380px;min-height:100vh;}
  @media(max-width:900px){.waiver-layout{grid-template-columns:1fr;}}
  .waiver-main{padding:48px;display:flex;flex-direction:column;max-width:800px;}
  .waiver-aside{background:var(--deep);border-left:1px solid var(--border);padding:48px;position:sticky;top:0;height:100vh;display:flex;flex-direction:column;}

  .brand-bar{display:flex;align-items:center;justify-content:space-between;margin-bottom:64px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .step-chip{font-size:10px;text-transform:uppercase;letter-spacing:0.16em;padding:6px 14px;border:1px solid rgba(201,168,76,0.3);color:var(--gold);}

  .waiver-header{margin-bottom:48px;}
  .waiver-label{display:flex;align-items:center;gap:16px;margin-bottom:20px;}
  .label-line{width:32px;height:1px;background:var(--gold);}
  .label-text{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.22em;}
  .waiver-header h1{font-family:'Playfair Display',serif;font-size:clamp(32px,5vw,52px);font-weight:900;color:var(--white);line-height:1;margin-bottom:16px;}
  .waiver-header h1 em{font-style:italic;color:var(--gold);}
  .waiver-header p{font-size:15px;color:var(--muted);line-height:1.75;}

  /* WAIVER DOCUMENT */
  .waiver-doc{background:var(--deep);border:1px solid var(--border);margin-bottom:40px;overflow:hidden;}
  .waiver-doc-header{padding:24px 32px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
  .waiver-doc-title{font-family:'Playfair Display',serif;font-size:18px;color:var(--white);}
  .waiver-doc-badge{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;padding:4px 12px;background:rgba(201,168,76,0.12);color:var(--gold);border:1px solid rgba(201,168,76,0.2);}
  .waiver-doc-body{padding:32px;max-height:320px;overflow-y:auto;}
  .waiver-doc-body::-webkit-scrollbar{width:4px;}
  .waiver-doc-body::-webkit-scrollbar-track{background:transparent;}
  .waiver-doc-body::-webkit-scrollbar-thumb{background:var(--border);}
  .waiver-section{margin-bottom:28px;}
  .waiver-section h4{font-size:12px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:10px;}
  .waiver-section p{font-size:13px;color:var(--muted);line-height:1.8;}

  /* CHECKBOXES */
  .consent-blocks{display:flex;flex-direction:column;gap:12px;margin-bottom:40px;}
  .consent-item{padding:20px 24px;border:1px solid var(--border);display:flex;gap:16px;align-items:flex-start;cursor:pointer;transition:border-color 0.3s;}
  .consent-item:hover,.consent-item.checked{border-color:rgba(201,168,76,0.4);}
  .consent-box{width:20px;height:20px;border:1px solid var(--border);flex-shrink:0;margin-top:1px;display:flex;align-items:center;justify-content:center;transition:all 0.3s;}
  .consent-item.checked .consent-box{background:var(--gold);border-color:var(--gold);}
  .consent-check{color:var(--ink);font-size:12px;font-weight:700;}
  .consent-text{font-size:13px;color:var(--muted);line-height:1.7;}

  /* SIGNATURE */
  .sig-section{margin-bottom:32px;}
  .sig-label{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);margin-bottom:12px;display:block;}
  .sig-canvas-wrap{border:1px solid var(--border);background:rgba(255,255,255,0.02);position:relative;margin-bottom:8px;}
  canvas{display:block;cursor:crosshair;width:100% !important;}
  .sig-hint{font-size:11px;color:var(--muted);text-align:center;position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;}
  .sig-clear{background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Outfit',sans-serif;font-size:11px;letter-spacing:0.1em;text-transform:uppercase;padding:8px 20px;cursor:pointer;transition:all 0.3s;margin-top:8px;}
  .sig-clear:hover{border-color:var(--gold);color:var(--gold);}
  .sig-name-group{margin-top:20px;}
  .input-label{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);margin-bottom:8px;display:block;}
  .input-field{width:100%;background:rgba(255,255,255,0.03);border:1px solid var(--border);padding:16px 18px;color:var(--white);font-family:'Outfit',sans-serif;font-size:14px;transition:border-color 0.3s;}
  .input-field:focus{border-color:var(--gold);outline:none;}

  .btn-sign{background:var(--gold);color:var(--ink);border:none;padding:20px 48px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;margin-top:32px;}
  .btn-sign:hover{background:var(--goldlt);transform:translateY(-2px);box-shadow:0 8px 24px rgba(201,168,76,0.25);}
  .btn-sign:disabled{opacity:0.4;cursor:not-allowed;transform:none;box-shadow:none;}

  /* ASIDE */
  .aside-booking-ref{margin-bottom:40px;padding-bottom:32px;border-bottom:1px solid var(--border);}
  .aside-ref-label{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:8px;display:block;}
  .aside-ref-num{font-family:'Playfair Display',serif;font-size:28px;color:var(--white);}
  .aside-detail-line{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);}
  .aside-detail-line:last-child{border-bottom:none;}
  .aside-dl-label{font-size:12px;color:var(--muted);}
  .aside-dl-value{font-size:12px;color:var(--foam);font-weight:500;}
  .signing-progress{margin-top:auto;padding-top:32px;border-top:1px solid var(--border);}
  .signing-progress-label{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:16px;display:block;}
  .signing-bar-track{height:3px;background:var(--border);width:100%;}
  .signing-bar-fill{height:3px;background:var(--gold);transition:width 0.5s ease;}

  /* SUCCESS */
  .signed-state{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:60px 0;}
  .signed-icon{font-size:56px;margin-bottom:24px;}
  .signed-title{font-family:'Playfair Display',serif;font-size:40px;color:var(--gold);margin-bottom:12px;}
  .signed-body{font-size:16px;color:var(--muted);line-height:1.75;max-width:420px;margin-bottom:40px;}
  .btn-continue{background:var(--gold);color:var(--ink);border:none;padding:20px 48px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;}
  .btn-continue:hover{background:var(--goldlt);}
`;

const waiverSections = [
  { title: "1. Assumption of Risk", body: "I understand that participation in maritime activities including deep-sea fishing, snorkelling, diving, and boating involves inherent risks including but not limited to drowning, injury from marine wildlife, adverse weather conditions, and vessel accidents. I voluntarily assume all such risks." },
  { title: "2. Release of Liability", body: "I hereby release and discharge Port Lucaya Marina, its officers, employees, agents, and affiliated charter operators from any and all claims, demands, or causes of action arising from my participation in the booked activity, to the fullest extent permitted by Bahamian law." },
  { title: "3. Medical Fitness", body: "I confirm that I am in good physical health and know of no medical condition, physical limitation, or disability that would prevent my safe participation in the booked water activity. I understand that scuba diving requires separate medical certification." },
  { title: "4. Equipment & Safety Briefing", body: "I agree to attend and comply with all safety briefings provided by Port Lucaya Marina staff and charter captains. I will use all provided safety equipment as directed and follow all instructions from the vessel captain at all times." },
  { title: "5. Cancellation Policy", body: "I understand that cancellations made more than 48 hours before the scheduled activity will receive a full refund. Cancellations within 48 hours will forfeit the deposit. No-shows will be charged the full booking amount." },
];

const consents = [
  "I have read and understand the full terms of this waiver",
  "I confirm I am 18 years of age or older (or acting as legal guardian)",
  "I agree to the cancellation and refund policy",
  "I consent to photography/video taken during the experience for Port Lucaya promotional use",
];

export default function WaiverPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [checked, setChecked] = useState<boolean[]>(consents.map(() => false));
  const [drawing, setDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [signed, setSigned] = useState(false);

  const allChecked = checked.every(Boolean);
  const canSign = allChecked && hasSignature;

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".brand-bar, .waiver-header, .waiver-doc, .consent-blocks, .sig-section", {
        y: 30, opacity: 0, stagger: 0.1, duration: 1, ease: "power3.out"
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  const startDraw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx2d = canvas.getContext("2d")!;
    const rect = canvas.getBoundingClientRect();
    ctx2d.beginPath();
    ctx2d.moveTo((e.clientX - rect.left) * (canvas.width / rect.width), (e.clientY - rect.top) * (canvas.height / rect.height));
    setDrawing(true);
  };
  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx2d = canvas.getContext("2d")!;
    const rect = canvas.getBoundingClientRect();
    ctx2d.lineWidth = 2; ctx2d.lineCap = "round"; ctx2d.strokeStyle = "#c9a84c";
    ctx2d.lineTo((e.clientX - rect.left) * (canvas.width / rect.width), (e.clientY - rect.top) * (canvas.height / rect.height));
    ctx2d.stroke();
    setHasSignature(true);
  };
  const stopDraw = () => setDrawing(false);
  const clearSig = () => {
    const canvas = canvasRef.current; if (!canvas) return;
    canvas.getContext("2d")!.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const toggleCheck = (i: number) => setChecked((prev) => prev.map((v, idx) => idx === i ? !v : v));
  const progress = (checked.filter(Boolean).length / consents.length) * 70 + (hasSignature ? 30 : 0);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <div className="waiver-layout">
        <div className="waiver-main">
          <div className="brand-bar">
            <div className="nav-logo">PORT LUCAYA<span>.</span></div>
            <span className="step-chip">Step 2 of 3 · Waiver</span>
          </div>

          {signed ? (
            <div className="signed-state">
              <div className="signed-icon">⚓</div>
              <h2 className="signed-title">Waiver Signed</h2>
              <p className="signed-body">Your liability waiver has been recorded and a copy sent to your email. You&apos;re all set for your experience at Port Lucaya.</p>
              <button className="btn-continue" onClick={() => window.location.href = "/book/confirmation"}>View Booking Confirmation →</button>
            </div>
          ) : (
            <>
              <div className="waiver-header">
                <div className="waiver-label"><div className="label-line" /><span className="label-text">Liability Waiver</span></div>
                <h1>Safety &amp; <em>Consent</em></h1>
                <p>Please read the full waiver carefully before signing. This document is required for all maritime activity bookings at Port Lucaya Marina.</p>
              </div>

              <div className="waiver-doc">
                <div className="waiver-doc-header">
                  <span className="waiver-doc-title">Port Lucaya Marina — Liability Waiver 2026</span>
                  <span className="waiver-doc-badge">Read Before Signing</span>
                </div>
                <div className="waiver-doc-body">
                  {waiverSections.map((s, i) => (
                    <div key={i} className="waiver-section">
                      <h4>{s.title}</h4>
                      <p>{s.body}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="consent-blocks">
                {consents.map((c, i) => (
                  <div key={i} className={`consent-item${checked[i] ? " checked" : ""}`} onClick={() => toggleCheck(i)}>
                    <div className="consent-box">{checked[i] && <span className="consent-check">✓</span>}</div>
                    <p className="consent-text">{c}</p>
                  </div>
                ))}
              </div>

              <div className="sig-section">
                <span className="sig-label">Your Signature</span>
                <div className="sig-canvas-wrap">
                  <canvas ref={canvasRef} width={600} height={160} onMouseDown={startDraw} onMouseMove={draw} onMouseUp={stopDraw} onMouseLeave={stopDraw} />
                  {!hasSignature && <p className="sig-hint">Sign here with your mouse or finger</p>}
                </div>
                <button className="sig-clear" onClick={clearSig}>Clear Signature</button>
                <div className="sig-name-group">
                  <label className="input-label">Full Legal Name (Print)</label>
                  <input className="input-field" placeholder="James Morrison" />
                </div>
              </div>

              <button className="btn-sign" disabled={!canSign} onClick={() => setSigned(true)}>
                {canSign ? "Sign Waiver & Continue →" : "Complete all items above to continue"}
              </button>
            </>
          )}
        </div>

        <div className="waiver-aside">
          <div className="aside-booking-ref">
            <span className="aside-ref-label">Booking Reference</span>
            <p className="aside-ref-num">#PLM-2026-8847</p>
          </div>
          <div>
            {[
              { label: "Experience", value: "Sunset Cruise" },
              { label: "Date", value: "14 March 2026" },
              { label: "Guests", value: "4 persons" },
              { label: "Vessel", value: "Sand Dollar" },
              { label: "Departure", value: "17:30 AST" },
            ].map((d) => (
              <div key={d.label} className="aside-detail-line">
                <span className="aside-dl-label">{d.label}</span>
                <span className="aside-dl-value">{d.value}</span>
              </div>
            ))}
          </div>
          <div className="signing-progress">
            <span className="signing-progress-label">Completion — {Math.round(progress)}%</span>
            <div className="signing-bar-track"><div className="signing-bar-fill" style={{ width: `${progress}%` }} /></div>
          </div>
        </div>
      </div>
    </div>
  );
}
