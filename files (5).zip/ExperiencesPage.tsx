"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');

  .plm-root {
    --ink:     #080c14;
    --deep:    #0a1628;
    --navy:    #0f2044;
    --steel:   #1e3a5f;
    --horizon: #2d5a8e;
    --foam:    #e8f4f8;
    --gold:    var(--tenant-primary-color, #c9a84c);
    --goldlt:  #e8c97a;
    --white:   #fafcff;
    --muted:   rgba(232,244,248,0.45);
    --border:  rgba(232,244,248,0.10);
    background: var(--ink);
    color: var(--foam);
    font-family: 'Outfit', sans-serif;
    overflow-x: hidden;
    min-height: 100vh;
  }
  .plm-root::before {
    content: '';
    position: fixed; inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
    pointer-events: none; z-index: 10; opacity: 0.6;
  }
  .plm-root *, .plm-root *::before, .plm-root *::after { box-sizing: border-box; margin: 0; padding: 0; }
  .reveal { opacity: 0; }

  /* NAV */
  .plm-nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 100;
    display: flex; justify-content: space-between; align-items: center;
    padding: 32px 48px;
    transition: background 0.4s, backdrop-filter 0.4s, padding 0.4s;
  }
  .plm-nav.scrolled {
    background: rgba(8,12,20,0.88); backdrop-filter: blur(20px);
    border-bottom: 1px solid var(--border); padding: 18px 48px;
  }
  .nav-logo { font-family: 'Playfair Display', serif; font-size: 20px; font-weight: 700; color: var(--white); letter-spacing: 0.02em; }
  .nav-logo span { color: var(--gold); }
  .nav-links { display: flex; gap: 40px; list-style: none; }
  .nav-links a { font-size: 12px; color: var(--muted); text-decoration: none; letter-spacing: 0.14em; text-transform: uppercase; transition: color 0.3s; }
  .nav-links a:hover, .nav-links a.active { color: var(--gold); }
  .nav-cta { background: transparent; border: 1px solid var(--gold); color: var(--gold); font-family: 'Outfit', sans-serif; font-size: 11px; font-weight: 500; letter-spacing: 0.12em; text-transform: uppercase; padding: 12px 28px; cursor: pointer; transition: all 0.3s; }
  .nav-cta:hover { background: var(--gold); color: var(--ink); }

  /* PAGE HERO */
  .page-hero {
    padding: 180px 48px 100px;
    background: linear-gradient(160deg, var(--deep) 0%, var(--ink) 60%);
    border-bottom: 1px solid var(--border);
    position: relative; overflow: hidden;
  }
  .page-hero::after {
    content: '';
    position: absolute; right: -100px; top: 50%; transform: translateY(-50%);
    width: 600px; height: 600px; border-radius: 50%;
    background: radial-gradient(circle, rgba(45,90,142,0.12) 0%, transparent 70%);
    pointer-events: none;
  }
  .page-hero-label { display: flex; align-items: center; gap: 16px; margin-bottom: 28px; }
  .label-line { width: 48px; height: 1px; background: var(--gold); }
  .label-text { font-size: 11px; font-weight: 500; color: var(--gold); letter-spacing: 0.22em; text-transform: uppercase; }
  .page-hero h1 { font-family: 'Playfair Display', serif; font-size: clamp(52px, 8vw, 96px); font-weight: 900; color: var(--white); line-height: 0.9; letter-spacing: -0.02em; }
  .page-hero h1 em { font-style: italic; color: var(--gold); font-weight: 400; }
  .page-hero p { font-size: 18px; font-weight: 300; color: var(--muted); line-height: 1.7; max-width: 560px; margin-top: 28px; }

  /* FILTER BAR */
  .filter-bar { padding: 40px 48px; background: var(--deep); border-bottom: 1px solid var(--border); display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
  .filter-btn { background: transparent; border: 1px solid var(--border); color: var(--muted); font-family: 'Outfit', sans-serif; font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; padding: 10px 20px; cursor: pointer; transition: all 0.3s; }
  .filter-btn:hover, .filter-btn.active { border-color: var(--gold); color: var(--gold); background: rgba(201,168,76,0.06); }

  /* EXPERIENCE GRID */
  .exp-section { padding: 100px 48px 140px; }
  .exp-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 2px; }
  @media (max-width: 1024px) { .exp-grid { grid-template-columns: repeat(2, 1fr); } }
  @media (max-width: 640px) { .exp-grid { grid-template-columns: 1fr; } }

  .exp-card {
    background: var(--deep);
    border: 1px solid var(--border);
    padding: 0;
    overflow: hidden;
    cursor: pointer;
    transition: border-color 0.4s;
    display: flex; flex-direction: column;
  }
  .exp-card:hover { border-color: rgba(201,168,76,0.4); }
  .exp-card:hover .exp-card-visual { transform: scale(1.03); }

  .exp-card-visual-wrap { height: 220px; overflow: hidden; position: relative; }
  .exp-card-visual {
    width: 100%; height: 100%;
    display: flex; align-items: center; justify-content: center;
    transition: transform 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }
  .exp-badge {
    position: absolute; top: 20px; left: 20px;
    font-size: 10px; letter-spacing: 0.16em; text-transform: uppercase;
    padding: 6px 14px; background: rgba(8,12,20,0.7); color: var(--gold);
    border: 1px solid rgba(201,168,76,0.3); backdrop-filter: blur(8px);
  }
  .featured-badge {
    position: absolute; top: 20px; right: 20px;
    font-size: 10px; letter-spacing: 0.12em; text-transform: uppercase;
    padding: 6px 14px; background: var(--gold); color: var(--ink); font-weight: 600;
  }

  .exp-card-body { padding: 40px; flex: 1; display: flex; flex-direction: column; }
  .exp-card-body h3 { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--white); margin-bottom: 14px; line-height: 1.2; }
  .exp-card-body p { font-size: 14px; color: var(--muted); line-height: 1.75; flex: 1; margin-bottom: 28px; }
  .exp-meta { display: flex; gap: 24px; padding-top: 24px; border-top: 1px solid var(--border); margin-bottom: 28px; }
  .exp-meta-item span { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.12em; display: block; margin-bottom: 4px; }
  .exp-meta-item p { font-size: 14px; color: var(--foam); font-weight: 500; }
  .exp-tags { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 28px; }
  .exp-tag { font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; padding: 5px 12px; border: 1px solid var(--border); color: var(--muted); }
  .exp-price { font-family: 'Playfair Display', serif; font-size: 14px; color: var(--muted); margin-bottom: 20px; }
  .exp-price strong { font-size: 32px; color: var(--gold); font-weight: 700; }
  .btn-book { background: var(--gold); color: var(--ink); border: none; padding: 16px 32px; font-size: 12px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; cursor: pointer; transition: all 0.3s; width: 100%; }
  .btn-book:hover { background: var(--goldlt); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(201,168,76,0.25); }

  /* FOOTER */
  footer { padding: 80px 48px; border-top: 1px solid var(--border); text-align: center; }
  .footer-text { font-size: 12px; color: var(--muted); letter-spacing: 0.08em; }
  .footer-text span { color: var(--gold); }
`;

const experiences = [
  {
    category: "Fishing",
    title: "Deep Sea Fishing Charter",
    description: "Trophy-class Marlin, Wahoo and Mahi-Mahi expeditions in the tongue of the Atlantic. Tournament-ready vessels, experienced captains, all tackle provided.",
    duration: "Half-day / Full-day",
    capacity: "Up to 6 guests",
    from: 450,
    tags: ["All Gear Included", "Licensed Captain", "Cooler & Ice"],
    featured: true,
    bg: "linear-gradient(135deg, #0a1f3d 0%, #0d2a4a 100%)",
  },
  {
    category: "Snorkelling",
    title: "Living Reef Snorkel Tour",
    description: "Explore Grand Bahama's premier reef systems. Crystal-clear visibility, coral gardens, sea turtles, and reef sharks in their natural habitat.",
    duration: "3 hours",
    capacity: "Up to 12 guests",
    from: 85,
    tags: ["Equipment Included", "Guided", "Family Friendly"],
    featured: false,
    bg: "linear-gradient(135deg, #082a35 0%, #0c3545 100%)",
  },
  {
    category: "Cruises",
    title: "Sunset Harbour Cruise",
    description: "Two hours of pure Bahamian magic — champagne, light catering, and front-row seats to a sky on fire. Private or small-group options available.",
    duration: "2 hours",
    capacity: "Up to 20 guests",
    from: 120,
    tags: ["Champagne Included", "Private Available", "Photography"],
    featured: true,
    bg: "linear-gradient(135deg, #1a1a0a 0%, #2a2a10 100%)",
  },
  {
    category: "Diving",
    title: "Scuba Diving Experience",
    description: "Wall dives, wreck dives, and blue hole exploration with certified PADI divemasters. Two-tank dives with equipment rental available on-site.",
    duration: "4 hours",
    capacity: "Up to 8 guests",
    from: 165,
    tags: ["PADI Certified", "Equipment Rental", "Two-Tank Dive"],
    featured: false,
    bg: "linear-gradient(135deg, #081228 0%, #0f1a38 100%)",
  },
  {
    category: "Water Sports",
    title: "Kayak & Paddleboard Hire",
    description: "Self-guided exploration of the marina's protected coves and mangrove channels. Perfect for a quiet morning before the day heats up.",
    duration: "Hourly / Half-day",
    capacity: "1–2 per vessel",
    from: 30,
    tags: ["Self-Guided", "No Experience Needed", "All Ages"],
    featured: false,
    bg: "linear-gradient(135deg, #0a1a10 0%, #0f2518 100%)",
  },
  {
    category: "Private Charter",
    title: "Full-Day Private Charter",
    description: "Bespoke island-hopping itinerary — swimming stops, lunch ashore, private snorkelling locations. Exclusive vessel and full crew for your group.",
    duration: "8 hours",
    capacity: "Up to 10 guests",
    from: 1200,
    tags: ["Bespoke Itinerary", "Full Crew", "Catering Available"],
    featured: true,
    bg: "linear-gradient(135deg, #14100a 0%, #1e1808 100%)",
  },
];

const ExpVisual = ({ bg, category }: { bg: string; category: string }) => (
  <div style={{ width: "100%", height: "100%", background: bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
    <svg viewBox="0 0 160 80" fill="none" width="120" opacity={0.25}>
      {category === "Fishing" && <>
        <path d="M20 60 Q80 10 140 60" stroke="#c9a84c" strokeWidth="1.5"/>
        <circle cx="80" cy="30" r="3" fill="#c9a84c"/>
        <line x1="80" y1="30" x2="80" y2="70" stroke="#c9a84c" strokeWidth="1"/>
      </>}
      {category === "Snorkelling" && <>
        <circle cx="80" cy="40" r="28" stroke="#c9a84c" strokeWidth="1.5"/>
        <circle cx="80" cy="40" r="14" stroke="#c9a84c" strokeWidth="1"/>
        <circle cx="80" cy="40" r="4" fill="#c9a84c"/>
      </>}
      {category === "Cruises" && <>
        <path d="M10 60 L150 60 L145 70 L15 70Z" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
        <rect x="50" y="35" width="60" height="25" stroke="#c9a84c" strokeWidth="1" fill="none"/>
        <line x1="80" y1="5" x2="80" y2="35" stroke="#c9a84c" strokeWidth="2"/>
        <path d="M80 8 L110 20 L80 32Z" stroke="#c9a84c" strokeWidth="1" fill="none"/>
      </>}
      {category === "Diving" && <>
        <ellipse cx="80" cy="40" rx="30" ry="22" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
        <path d="M60 55 Q80 65 100 55" stroke="#c9a84c" strokeWidth="1"/>
        <circle cx="80" cy="38" r="5" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
      </>}
      {category === "Water Sports" && <>
        <path d="M20 50 Q50 30 80 50 Q110 70 140 50" stroke="#c9a84c" strokeWidth="1.5"/>
        <ellipse cx="80" cy="35" rx="12" ry="8" stroke="#c9a84c" strokeWidth="1" fill="none"/>
        <line x1="80" y1="35" x2="80" y2="55" stroke="#c9a84c" strokeWidth="1.5"/>
      </>}
      {category === "Private Charter" && <>
        <path d="M10 60 L150 60 L140 72 L20 72Z" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
        <rect x="40" y="38" width="80" height="22" stroke="#c9a84c" strokeWidth="1" fill="none"/>
        <rect x="55" y="22" width="50" height="16" stroke="#c9a84c" strokeWidth="1" fill="none"/>
        <line x1="80" y1="4" x2="80" y2="22" stroke="#c9a84c" strokeWidth="2"/>
      </>}
    </svg>
  </div>
);

export default function ExperiencesPage() {
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".page-hero h1, .page-hero p, .page-hero-label", {
        y: 50, opacity: 0, stagger: 0.15, duration: 1.2, ease: "power4.out"
      });
      const reveals = gsap.utils.toArray<HTMLElement>(".reveal");
      reveals.forEach((el) => {
        gsap.fromTo(el,
          { y: 50, opacity: 0 },
          { scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" },
            y: 0, opacity: 1, duration: 1.1, ease: "power3.out" }
        );
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>

      <nav className="plm-nav" id="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h} className={l === "Experiences" ? "active" : ""}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="page-hero">
        <div className="page-hero-label">
          <div className="label-line" />
          <span className="label-text">Freeport · Grand Bahama</span>
        </div>
        <h1>Maritime<br /><em>Experiences</em></h1>
        <p>From deep-sea fishing to sunset cruises — curated water adventures departing daily from Port Lucaya Marina.</p>
      </section>

      <div className="filter-bar">
        {["All", "Fishing", "Snorkelling", "Cruises", "Diving", "Water Sports", "Private Charter"].map((cat, i) => (
          <button key={cat} className={`filter-btn${i === 0 ? " active" : ""}`}>{cat}</button>
        ))}
      </div>

      <section className="exp-section">
        <div className="exp-grid">
          {experiences.map((exp, i) => (
            <div key={i} className="exp-card reveal">
              <div className="exp-card-visual-wrap">
                <div className="exp-card-visual">
                  <ExpVisual bg={exp.bg} category={exp.category} />
                </div>
                <div className="exp-badge">{exp.category}</div>
                {exp.featured && <div className="featured-badge">Featured</div>}
              </div>
              <div className="exp-card-body">
                <h3>{exp.title}</h3>
                <p>{exp.description}</p>
                <div className="exp-meta">
                  <div className="exp-meta-item">
                    <span>Duration</span>
                    <p>{exp.duration}</p>
                  </div>
                  <div className="exp-meta-item">
                    <span>Capacity</span>
                    <p>{exp.capacity}</p>
                  </div>
                </div>
                <div className="exp-tags">
                  {exp.tags.map((tag) => <span key={tag} className="exp-tag">{tag}</span>)}
                </div>
                <div className="exp-price">From <strong>${exp.from}</strong></div>
                <button className="btn-book" onClick={() => window.location.href = "/book"}>Reserve This Experience</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
