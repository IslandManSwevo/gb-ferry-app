"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}

  .confirm-wrap{max-width:1100px;margin:0 auto;padding:64px 48px;}

  /* BRAND */
  .brand-bar{display:flex;align-items:center;justify-content:space-between;margin-bottom:80px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .home-link{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.1em;text-transform:uppercase;transition:color 0.3s;cursor:pointer;}
  .home-link:hover{color:var(--gold);}

  /* HERO CONFIRMATION */
  .confirm-hero{text-align:center;margin-bottom:80px;}
  .confirm-badge{width:80px;height:80px;border-radius:50%;border:1px solid var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 32px;font-size:32px;}
  .confirm-hero h1{font-family:'Playfair Display',serif;font-size:clamp(40px,7vw,80px);font-weight:900;color:var(--white);line-height:0.9;letter-spacing:-0.02em;margin-bottom:16px;}
  .confirm-hero h1 em{font-style:italic;color:var(--gold);}
  .confirm-hero p{font-size:17px;color:var(--muted);line-height:1.75;max-width:480px;margin:0 auto;}
  .confirm-ref{display:inline-block;margin-top:24px;padding:12px 28px;border:1px solid rgba(201,168,76,0.4);font-size:14px;color:var(--gold);letter-spacing:0.06em;}

  /* BOOKING CARD */
  .booking-card{background:var(--deep);border:1px solid var(--border);margin-bottom:32px;overflow:hidden;}
  .booking-card-header{padding:28px 40px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
  .booking-card-header h3{font-family:'Playfair Display',serif;font-size:22px;color:var(--white);}
  .status-badge{font-size:10px;text-transform:uppercase;letter-spacing:0.16em;padding:6px 14px;background:rgba(34,197,94,0.12);color:#4ade80;border:1px solid rgba(34,197,94,0.25);}
  .booking-details-grid{display:grid;grid-template-columns:repeat(3,1fr);border-bottom:1px solid var(--border);}
  @media(max-width:700px){.booking-details-grid{grid-template-columns:repeat(2,1fr);}}
  .detail-cell{padding:28px 40px;border-right:1px solid var(--border);}
  .detail-cell:last-child{border-right:none;}
  .detail-cell span{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;display:block;margin-bottom:6px;}
  .detail-cell p{font-size:15px;color:var(--foam);font-weight:500;}

  .payment-summary{padding:28px 40px;}
  .payment-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);}
  .payment-row:last-child{border-bottom:none;padding-top:16px;}
  .payment-row-label{font-size:13px;color:var(--muted);}
  .payment-row-value{font-size:13px;color:var(--foam);font-weight:500;}
  .payment-total .payment-row-label{font-size:15px;color:var(--foam);font-weight:600;}
  .payment-total .payment-row-value{font-family:'Playfair Display',serif;font-size:28px;color:var(--gold);font-weight:700;}

  /* NEXT STEPS */
  .next-section{margin-bottom:64px;}
  .next-section h2{font-family:'Playfair Display',serif;font-size:36px;color:var(--white);margin-bottom:32px;}
  .next-section h2 em{font-style:italic;color:var(--gold);}
  .steps-list{display:flex;flex-direction:column;gap:2px;}
  .step-item{display:flex;gap:24px;align-items:flex-start;padding:28px 32px;background:var(--deep);border:1px solid var(--border);}
  .step-num{width:36px;height:36px;border-radius:50%;border:1px solid var(--gold);color:var(--gold);display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;font-family:'Playfair Display',serif;}
  .step-body h4{font-size:16px;color:var(--foam);margin-bottom:6px;}
  .step-body p{font-size:13px;color:var(--muted);line-height:1.7;}

  /* ACTIONS */
  .action-row{display:flex;gap:16px;flex-wrap:wrap;}
  .btn-primary{background:var(--gold);color:var(--ink);border:none;padding:18px 40px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;}
  .btn-primary:hover{background:var(--goldlt);transform:translateY(-2px);}
  .btn-outline{background:transparent;border:1px solid var(--border);color:var(--foam);padding:18px 40px;font-size:12px;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;}
  .btn-outline:hover{border-color:var(--gold);color:var(--gold);}

  /* WHATSAPP */
  .whatsapp-banner{background:rgba(37,211,102,0.06);border:1px solid rgba(37,211,102,0.2);padding:28px 40px;display:flex;align-items:center;gap:24px;margin-bottom:64px;}
  .wa-icon{font-size:28px;flex-shrink:0;}
  .wa-copy h4{font-size:16px;color:var(--foam);margin-bottom:4px;}
  .wa-copy p{font-size:13px;color:var(--muted);line-height:1.6;}
  .wa-btn{margin-left:auto;background:#25d366;color:white;border:none;padding:12px 24px;font-family:'Outfit',sans-serif;font-size:11px;font-weight:600;letter-spacing:0.1em;text-transform:uppercase;cursor:pointer;white-space:nowrap;flex-shrink:0;}

  footer{padding:60px 0 0;border-top:1px solid var(--border);text-align:center;}
  .footer-text{font-size:12px;color:var(--muted);letter-spacing:0.08em;}
  .footer-text span{color:var(--gold);}
`;

export default function ConfirmationPage() {
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".confirm-badge", { scale: 0, opacity: 0, duration: 0.8, ease: "back.out(1.7)" });
      gsap.from(".confirm-hero h1, .confirm-hero p, .confirm-ref", { y: 30, opacity: 0, stagger: 0.15, duration: 1, ease: "power3.out", delay: 0.3 });
      gsap.from(".booking-card, .whatsapp-banner, .next-section, .action-row", { y: 40, opacity: 0, stagger: 0.15, duration: 1, ease: "power3.out", delay: 0.6 });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <div className="confirm-wrap">
        <div className="brand-bar">
          <div className="nav-logo">PORT LUCAYA<span>.</span></div>
          <span className="home-link" onClick={() => window.location.href = "/"}>← Return to Marina</span>
        </div>

        <div className="confirm-hero">
          <div className="confirm-badge">⚓</div>
          <h1>You&apos;re <em>Booked</em></h1>
          <p>Your experience at Port Lucaya Marina is confirmed. A full summary and receipt have been sent to your email.</p>
          <span className="confirm-ref">Booking Reference: #PLM-2026-8847</span>
        </div>

        <div className="booking-card">
          <div className="booking-card-header">
            <h3>Sunset Harbour Cruise</h3>
            <span className="status-badge">Confirmed</span>
          </div>
          <div className="booking-details-grid">
            {[
              { label: "Date", value: "Saturday, 14 March 2026" },
              { label: "Departure", value: "17:30 AST" },
              { label: "Guests", value: "4 persons" },
              { label: "Vessel", value: "Sand Dollar" },
              { label: "Duration", value: "2 hours" },
              { label: "Meeting Point", value: "Dock B, Slip 14" },
            ].map((d) => (
              <div key={d.label} className="detail-cell">
                <span>{d.label}</span>
                <p>{d.value}</p>
              </div>
            ))}
          </div>
          <div className="payment-summary">
            {[
              { label: "Sunset Cruise × 4 guests", value: "$480.00" },
              { label: "VAT (12%)", value: "$57.60" },
              { label: "Deposit paid today", value: "−$268.80" },
            ].map((r) => (
              <div key={r.label} className="payment-row">
                <span className="payment-row-label">{r.label}</span>
                <span className="payment-row-value">{r.value}</span>
              </div>
            ))}
            <div className="payment-row payment-total">
              <span className="payment-row-label">Balance due on arrival</span>
              <span className="payment-row-value">$268.80</span>
            </div>
          </div>
        </div>

        <div className="whatsapp-banner">
          <span className="wa-icon">💬</span>
          <div className="wa-copy">
            <h4>Get updates on WhatsApp</h4>
            <p>We&apos;ll send your departure reminder, weather updates, and any changes directly to your WhatsApp.</p>
          </div>
          <button className="wa-btn">Connect on WhatsApp</button>
        </div>

        <div className="next-section">
          <h2>What happens <em>next</em></h2>
          <div className="steps-list">
            {[
              { num: "01", title: "Check your email", body: "A full booking confirmation and receipt has been sent to your registered email address. Check your spam folder if it doesn't arrive within 5 minutes." },
              { num: "02", title: "Sign your waiver", body: "If you haven't already, complete the online liability waiver. All guests must sign before boarding. A link has been included in your confirmation email." },
              { num: "03", title: "Arrive at Dock B", body: "Please arrive at Dock B, Slip 14, at least 15 minutes before your scheduled departure. Our crew will be ready to welcome you aboard." },
              { num: "04", title: "Pay your balance on arrival", body: "The remaining $268.80 balance is due on arrival. We accept USD cash, card, PayPal, and Sand Dollar CBDC." },
            ].map((s) => (
              <div key={s.num} className="step-item">
                <div className="step-num">{s.num}</div>
                <div className="step-body"><h4>{s.title}</h4><p>{s.body}</p></div>
              </div>
            ))}
          </div>
        </div>

        <div className="action-row">
          <button className="btn-primary" onClick={() => window.print()}>Download Receipt</button>
          <button className="btn-outline" onClick={() => window.location.href = "/book/waiver"}>Sign Waiver</button>
          <button className="btn-outline" onClick={() => window.location.href = "/portal"}>View in My Account</button>
          <button className="btn-outline" onClick={() => window.location.href = "/contact"}>Contact the Marina</button>
        </div>

        <footer style={{ marginTop: 64 }}>
          <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
        </footer>
      </div>
    </div>
  );
}
