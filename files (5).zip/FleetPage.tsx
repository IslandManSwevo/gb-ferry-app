"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root {
    --ink: #080c14; --deep: #0a1628; --navy: #0f2044; --steel: #1e3a5f; --horizon: #2d5a8e;
    --foam: #e8f4f8; --gold: var(--tenant-primary-color, #c9a84c); --goldlt: #e8c97a;
    --white: #fafcff; --muted: rgba(232,244,248,0.45); --border: rgba(232,244,248,0.10);
    background: var(--ink); color: var(--foam); font-family: 'Outfit', sans-serif;
    overflow-x: hidden; min-height: 100vh;
  }
  .plm-root::before { content:''; position:fixed; inset:0; background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E"); pointer-events:none; z-index:10; opacity:0.6; }
  .plm-root *, .plm-root *::before, .plm-root *::after { box-sizing:border-box; margin:0; padding:0; }
  .reveal { opacity: 0; }

  .plm-nav { position:fixed; top:0; left:0; right:0; z-index:100; display:flex; justify-content:space-between; align-items:center; padding:32px 48px; transition:background 0.4s,backdrop-filter 0.4s,padding 0.4s; }
  .plm-nav.scrolled { background:rgba(8,12,20,0.88); backdrop-filter:blur(20px); border-bottom:1px solid var(--border); padding:18px 48px; }
  .nav-logo { font-family:'Playfair Display',serif; font-size:20px; font-weight:700; color:var(--white); letter-spacing:0.02em; }
  .nav-logo span { color:var(--gold); }
  .nav-links { display:flex; gap:40px; list-style:none; }
  .nav-links a { font-size:12px; color:var(--muted); text-decoration:none; letter-spacing:0.14em; text-transform:uppercase; transition:color 0.3s; }
  .nav-links a:hover, .nav-links a.active { color:var(--gold); }
  .nav-cta { background:transparent; border:1px solid var(--gold); color:var(--gold); font-family:'Outfit',sans-serif; font-size:11px; font-weight:500; letter-spacing:0.12em; text-transform:uppercase; padding:12px 28px; cursor:pointer; transition:all 0.3s; }
  .nav-cta:hover { background:var(--gold); color:var(--ink); }

  .page-hero { padding:180px 48px 100px; background:linear-gradient(160deg, var(--deep) 0%, var(--ink) 60%); border-bottom:1px solid var(--border); position:relative; overflow:hidden; }
  .page-hero-label { display:flex; align-items:center; gap:16px; margin-bottom:28px; }
  .label-line { width:48px; height:1px; background:var(--gold); }
  .label-text { font-size:11px; font-weight:500; color:var(--gold); letter-spacing:0.22em; text-transform:uppercase; }
  .page-hero h1 { font-family:'Playfair Display',serif; font-size:clamp(52px,8vw,96px); font-weight:900; color:var(--white); line-height:0.9; letter-spacing:-0.02em; }
  .page-hero h1 em { font-style:italic; color:var(--gold); font-weight:400; }
  .page-hero p { font-size:18px; font-weight:300; color:var(--muted); line-height:1.7; max-width:560px; margin-top:28px; }

  /* FLEET HERO VESSEL */
  .hero-vessel { position:absolute; right:5%; bottom:0; width:50%; max-width:700px; opacity:0.15; pointer-events:none; }

  /* SLIP STATS */
  .slip-stats { display:grid; grid-template-columns:repeat(4,1fr); border-top:1px solid var(--border); border-bottom:1px solid var(--border); background:var(--deep); }
  .slip-stat { padding:48px; text-align:center; border-right:1px solid var(--border); }
  .slip-stat:last-child { border-right:none; }
  .slip-val { font-family:'Playfair Display',serif; font-size:44px; font-weight:700; color:var(--gold); margin-bottom:8px; }
  .slip-lab { font-size:10px; text-transform:uppercase; letter-spacing:0.2em; color:var(--muted); }

  /* VESSEL CARDS */
  .fleet-section { padding:120px 48px 160px; }
  .fleet-intro { max-width:680px; margin:0 auto 80px; text-align:center; }
  .fleet-intro h2 { font-family:'Playfair Display',serif; font-size:clamp(40px,6vw,72px); color:var(--white); line-height:1; margin-bottom:20px; }
  .fleet-intro h2 em { font-style:italic; color:var(--gold); }
  .fleet-intro p { font-size:16px; color:var(--muted); line-height:1.8; }

  .vessel-cards { display:flex; flex-direction:column; gap:2px; }
  .vessel-card {
    display:grid; grid-template-columns:1fr 1fr; background:var(--deep);
    border:1px solid var(--border); overflow:hidden; transition:border-color 0.4s;
  }
  .vessel-card:nth-child(even) { direction:rtl; }
  .vessel-card:nth-child(even) > * { direction:ltr; }
  .vessel-card:hover { border-color:rgba(201,168,76,0.35); }
  @media(max-width:768px) { .vessel-card, .vessel-card:nth-child(even) { grid-template-columns:1fr; direction:ltr; } }

  .vessel-visual {
    min-height:360px; display:flex; align-items:center; justify-content:center;
    position:relative; overflow:hidden;
  }
  .vessel-visual::after { content:''; position:absolute; inset:0; background:linear-gradient(135deg,rgba(8,12,20,0.3),transparent); }

  .vessel-body { padding:64px; display:flex; flex-direction:column; justify-content:center; }
  .vessel-class { font-size:10px; color:var(--gold); text-transform:uppercase; letter-spacing:0.2em; margin-bottom:16px; display:block; }
  .vessel-name { font-family:'Playfair Display',serif; font-size:clamp(32px,4vw,52px); color:var(--white); line-height:1; margin-bottom:20px; }
  .vessel-desc { font-size:15px; color:var(--muted); line-height:1.75; margin-bottom:40px; }
  .vessel-specs { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; padding-top:32px; border-top:1px solid var(--border); margin-bottom:40px; }
  .spec-item span { font-size:10px; color:var(--muted); text-transform:uppercase; letter-spacing:0.14em; display:block; margin-bottom:6px; }
  .spec-item p { font-size:18px; color:var(--foam); font-weight:500; }
  .vessel-amenities { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:36px; }
  .amenity-tag { font-size:10px; letter-spacing:0.1em; text-transform:uppercase; padding:5px 12px; border:1px solid var(--border); color:var(--muted); }
  .btn-charter { background:var(--gold); color:var(--ink); border:none; padding:16px 36px; font-size:12px; font-weight:600; letter-spacing:0.12em; text-transform:uppercase; cursor:pointer; transition:all 0.3s; }
  .btn-charter:hover { background:var(--goldlt); transform:translateY(-2px); box-shadow:0 8px 24px rgba(201,168,76,0.25); }

  /* MARINA AMENITIES */
  .amenities-section { background:#060a14; padding:120px 48px; border-top:1px solid var(--border); }
  .amenities-head { text-align:center; margin-bottom:80px; }
  .amenities-head h2 { font-family:'Playfair Display',serif; font-size:clamp(36px,5vw,64px); color:var(--white); }
  .amenities-head h2 em { font-style:italic; color:var(--gold); }
  .amenities-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:2px; max-width:1400px; margin:0 auto; }
  @media(max-width:768px) { .amenities-grid { grid-template-columns:repeat(2,1fr); } .slip-stats { grid-template-columns:repeat(2,1fr); } }
  .amenity-card { padding:40px; background:var(--deep); border:1px solid var(--border); text-align:center; transition:border-color 0.3s; }
  .amenity-card:hover { border-color:rgba(201,168,76,0.3); }
  .amenity-icon { font-size:28px; margin-bottom:16px; opacity:0.8; }
  .amenity-card h4 { font-family:'Playfair Display',serif; font-size:18px; color:var(--white); margin-bottom:10px; }
  .amenity-card p { font-size:13px; color:var(--muted); line-height:1.6; }

  footer { padding:80px 48px; border-top:1px solid var(--border); text-align:center; }
  .footer-text { font-size:12px; color:var(--muted); letter-spacing:0.08em; }
  .footer-text span { color:var(--gold); }
`;

const vessels = [
  {
    name: "Marlin Queen",
    class: "52′ Custom Sportfisher",
    desc: "Our flagship vessel. Purpose-built for blue-water fishing and private charter work. Twin diesel power, full fighting chair rig, climate-controlled cabin, and an experienced dedicated crew.",
    specs: [
      { label: "LOA", value: "52 ft" },
      { label: "Capacity", value: "12 guests" },
      { label: "Top Speed", value: "34 knots" },
    ],
    amenities: ["Fighting Chair", "Live Bait Well", "Full Galley", "A/C Cabin", "Outriggers", "Fish Finder"],
    bg: "linear-gradient(135deg, #0a1f3d 0%, #0f2a4a 100%)",
  },
  {
    name: "Island Runner",
    class: "38′ Fountain Center Console",
    desc: "Speed, agility, and open-water access. Perfect for snorkel tours, reef exploration, and high-speed island-hopping. The go-to vessel for guests who want to cover ground.",
    specs: [
      { label: "LOA", value: "38 ft" },
      { label: "Capacity", value: "8 guests" },
      { label: "Top Speed", value: "52 knots" },
    ],
    amenities: ["Twin 300HP", "Dive Platform", "Cooler", "Electronics Suite", "T-Top Shade"],
    bg: "linear-gradient(135deg, #0a1628 0%, #152238 100%)",
  },
  {
    name: "Sand Dollar",
    class: "28′ Grady-White Dual Console",
    desc: "Intimate charters for couples and small families. Ideal for sunset cruises, paddleboard drop-offs, and half-day reef fishing. Simple, elegant, effortless.",
    specs: [
      { label: "LOA", value: "28 ft" },
      { label: "Capacity", value: "6 guests" },
      { label: "Top Speed", value: "42 knots" },
    ],
    amenities: ["Bow Seating", "Aft Bench", "Bimini Top", "Bluetooth Audio", "Swim Ladder"],
    bg: "linear-gradient(135deg, #0d1a28 0%, #1a2d40 100%)",
  },
];

const VesselSVG = ({ type }: { type: number }) => (
  <svg viewBox="0 0 600 300" fill="none" width="80%" opacity={0.3}>
    {type === 0 && <>
      <path d="M50 200 L550 200 L580 230 L20 230Z" fill="var(--navy)" stroke="var(--steel)" strokeWidth="2"/>
      <rect x="180" y="140" width="240" height="60" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
      <rect x="220" y="100" width="160" height="40" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
      <line x1="300" y1="20" x2="300" y2="100" stroke="var(--gold)" strokeWidth="2.5"/>
      <path d="M300 20 L360 40 L300 60Z" fill="var(--gold)" opacity="0.8"/>
      <rect x="100" y="170" width="30" height="30" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
      <line x1="80" y1="200" x2="520" y2="200" stroke="var(--steel)" strokeWidth="1"/>
    </>}
    {type === 1 && <>
      <path d="M80 185 L520 185 L540 210 L60 210Z" fill="var(--navy)" stroke="var(--steel)" strokeWidth="2"/>
      <rect x="220" y="145" width="160" height="40" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
      <line x1="300" y1="30" x2="300" y2="145" stroke="var(--gold)" strokeWidth="2"/>
      <path d="M300 32 L340 70 L300 108Z" stroke="var(--gold)" strokeWidth="1.5" fill="none"/>
      <circle cx="300" cy="145" r="6" fill="var(--gold)"/>
    </>}
    {type === 2 && <>
      <path d="M100 180 L500 180 L520 205 L80 205Z" fill="var(--navy)" stroke="var(--steel)" strokeWidth="2"/>
      <rect x="200" y="150" width="200" height="30" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
      <line x1="300" y1="60" x2="300" y2="150" stroke="var(--gold)" strokeWidth="2"/>
      <path d="M300 62 L330 90 L300 118Z" stroke="var(--gold)" strokeWidth="1.5" fill="none"/>
    </>}
  </svg>
);

export default function FleetPage() {
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".page-hero h1, .page-hero p, .page-hero-label", {
        y: 50, opacity: 0, stagger: 0.15, duration: 1.2, ease: "power4.out"
      });
      gsap.from(".hero-vessel", { x: 80, opacity: 0, duration: 2, ease: "expo.out", delay: 0.5 });
      const reveals = gsap.utils.toArray<HTMLElement>(".reveal");
      reveals.forEach((el) => {
        gsap.fromTo(el,
          { y: 50, opacity: 0 },
          { scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" },
            y: 0, opacity: 1, duration: 1.1, ease: "power3.out" }
        );
      });
      gsap.utils.toArray<HTMLElement>(".vessel-card").forEach(card => {
        card.addEventListener("mouseenter", () => gsap.to(card, { y: -4, duration: 0.4 }));
        card.addEventListener("mouseleave", () => gsap.to(card, { y: 0, duration: 0.4 }));
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>

      <nav className="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h} className={l === "The Fleet" ? "active" : ""}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="page-hero">
        <div className="page-hero-label">
          <div className="label-line" />
          <span className="label-text">106 Slips · 190ft LOA Capacity</span>
        </div>
        <h1>The <em>Fleet</em></h1>
        <p>Purpose-built vessels for every adventure. Professionally crewed, fully equipped, and maintained to the highest maritime standards.</p>
        <div className="hero-vessel">
          <VesselSVG type={0} />
        </div>
      </section>

      <div className="slip-stats">
        {[
          { v: "106", l: "Total Slips" },
          { v: "190ft", l: "Max LOA" },
          { v: "8ft", l: "Draft Depth" },
          { v: "50/200A", l: "Shore Power" },
        ].map((s, i) => (
          <div key={i} className="slip-stat reveal">
            <div className="slip-val">{s.v}</div>
            <div className="slip-lab">{s.l}</div>
          </div>
        ))}
      </div>

      <section className="fleet-section">
        <div className="fleet-intro reveal">
          <h2>Charter <em>Vessels</em></h2>
          <p>Three hand-selected vessels covering every adventure type — from tournament fishing to private sunset cruises. Each maintained to commercial maritime standards.</p>
        </div>
        <div className="vessel-cards">
          {vessels.map((v, i) => (
            <div key={i} className="vessel-card reveal">
              <div className="vessel-visual" style={{ background: v.bg }}>
                <VesselSVG type={i} />
              </div>
              <div className="vessel-body">
                <span className="vessel-class">{v.class}</span>
                <h3 className="vessel-name">{v.name}</h3>
                <p className="vessel-desc">{v.desc}</p>
                <div className="vessel-specs">
                  {v.specs.map((spec) => (
                    <div key={spec.label} className="spec-item">
                      <span>{spec.label}</span>
                      <p>{spec.value}</p>
                    </div>
                  ))}
                </div>
                <div className="vessel-amenities">
                  {v.amenities.map((a) => <span key={a} className="amenity-tag">{a}</span>)}
                </div>
                <button className="btn-charter" onClick={() => window.location.href = "/book"}>Charter This Vessel</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="amenities-section">
        <div className="amenities-head reveal">
          <h2>Marina <em>Amenities</em></h2>
        </div>
        <div className="amenities-grid">
          {[
            { icon: "⚡", title: "Shore Power", desc: "50/200 amp service at every slip" },
            { icon: "🌐", title: "Wi-Fi", desc: "High-speed marina-wide coverage" },
            { icon: "🚿", title: "Showers", desc: "Private shower facilities dockside" },
            { icon: "🧊", title: "Ice & Water", desc: "Dockside ice and fresh water" },
            { icon: "🍽️", title: "Restaurant", desc: "On-site bar and dining" },
            { icon: "🎣", title: "Tackle & Bait", desc: "Fully stocked tackle shop" },
            { icon: "✈️", title: "Port of Entry", desc: "Official Bahamian port of entry" },
            { icon: "🔧", title: "Marine Services", desc: "Engine and hull service on request" },
          ].map((a, i) => (
            <div key={i} className="amenity-card reveal">
              <div className="amenity-icon">{a.icon}</div>
              <h4>{a.title}</h4>
              <p>{a.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
