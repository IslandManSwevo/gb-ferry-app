"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#060810;--deep:#090e1c;--navy:#0f2044;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.08);--positive:rgba(74,222,128,0.85);--warn:#f59e0b;--danger:rgba(255,99,99,0.85);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}

  .ops-layout{display:grid;grid-template-columns:240px 1fr;min-height:100vh;}
  @media(max-width:900px){.ops-layout{grid-template-columns:1fr;}}
  .ops-sidebar{background:var(--deep);border-right:1px solid var(--border);padding:32px 24px;display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto;}
  .ops-main{padding:32px 40px;overflow-y:auto;}

  .sidebar-brand{margin-bottom:40px;}
  .sidebar-brand-top{font-family:'Playfair Display',serif;font-size:16px;font-weight:700;color:var(--white);}
  .sidebar-brand-top span{color:var(--gold);}
  .sidebar-brand-sub{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-top:2px;}

  .ops-nav{display:flex;flex-direction:column;gap:2px;flex:1;}
  .ops-nav-section{font-size:9px;color:rgba(232,244,248,0.25);text-transform:uppercase;letter-spacing:0.2em;padding:16px 12px 6px;margin-top:8px;}
  .ops-nav-item{display:flex;align-items:center;gap:12px;padding:11px 14px;font-size:12px;color:var(--muted);cursor:pointer;border-left:2px solid transparent;transition:all 0.25s;letter-spacing:0.03em;}
  .ops-nav-item:hover{color:var(--foam);background:rgba(255,255,255,0.03);}
  .ops-nav-item.active{color:var(--gold);border-left-color:var(--gold);background:rgba(201,168,76,0.05);}
  .ops-nav-icon{font-size:14px;opacity:0.8;width:18px;text-align:center;}
  .ops-nav-badge{margin-left:auto;background:rgba(201,168,76,0.2);color:var(--gold);font-size:10px;padding:2px 8px;border-radius:10px;}

  .ops-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;padding-bottom:24px;border-bottom:1px solid var(--border);}
  .ops-topbar-left h2{font-family:'Playfair Display',serif;font-size:28px;color:var(--white);}
  .ops-topbar-left p{font-size:12px;color:var(--muted);margin-top:2px;}
  .ops-topbar-right{display:flex;align-items:center;gap:12px;}
  .ops-date{font-size:12px;color:var(--muted);padding:8px 16px;border:1px solid var(--border);}
  .ops-alert-bell{width:36px;height:36px;border:1px solid var(--border);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;position:relative;transition:border-color 0.3s;}
  .ops-alert-bell:hover{border-color:var(--gold);}
  .bell-dot{position:absolute;top:6px;right:6px;width:6px;height:6px;border-radius:50%;background:var(--gold);}

  /* KPI STRIP */
  .kpi-strip{display:grid;grid-template-columns:repeat(5,1fr);gap:1px;margin-bottom:32px;border:1px solid var(--border);}
  @media(max-width:1100px){.kpi-strip{grid-template-columns:repeat(3,1fr);}}
  .kpi{padding:20px 24px;background:var(--deep);}
  .kpi-label{font-size:9px;text-transform:uppercase;letter-spacing:0.18em;color:var(--muted);margin-bottom:6px;display:block;}
  .kpi-val{font-family:'Playfair Display',serif;font-size:28px;color:var(--white);font-weight:700;line-height:1;}
  .kpi-delta{font-size:11px;margin-top:4px;}
  .delta-up{color:var(--positive);}
  .delta-down{color:var(--danger);}

  /* TODAY'S MANIFEST */
  .dash-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:32px;}
  @media(max-width:1100px){.dash-grid{grid-template-columns:1fr;}}
  .panel{background:var(--deep);border:1px solid var(--border);}
  .panel-head{padding:16px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
  .panel-head h3{font-size:13px;color:var(--foam);font-weight:500;letter-spacing:0.04em;}
  .panel-head-action{font-size:11px;color:var(--gold);cursor:pointer;text-transform:uppercase;letter-spacing:0.1em;background:none;border:none;}
  .manifest-list{padding:0;}
  .manifest-row{display:grid;grid-template-columns:auto 1fr auto auto;gap:12px;align-items:center;padding:14px 24px;border-bottom:1px solid var(--border);transition:background 0.2s;}
  .manifest-row:last-child{border-bottom:none;}
  .manifest-row:hover{background:rgba(255,255,255,0.02);}
  .manifest-time{font-size:12px;color:var(--gold);font-weight:500;width:52px;flex-shrink:0;}
  .manifest-name{font-size:13px;color:var(--foam);}
  .manifest-experience{font-size:11px;color:var(--muted);}
  .manifest-guests{font-size:11px;color:var(--muted);white-space:nowrap;}
  .manifest-dot{width:6px;height:6px;border-radius:50%;}

  /* PAYMENTS */
  .payment-list{padding:0;}
  .payment-row{display:flex;align-items:center;gap:12px;padding:14px 24px;border-bottom:1px solid var(--border);}
  .payment-row:last-child{border-bottom:none;}
  .payment-icon{font-size:18px;opacity:0.7;flex-shrink:0;}
  .payment-info{flex:1;}
  .payment-info-name{font-size:13px;color:var(--foam);}
  .payment-info-meta{font-size:11px;color:var(--muted);}
  .payment-amount{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;}
  .amount-in{color:var(--positive);}
  .amount-out{color:var(--danger);}

  /* SLIP BOARD */
  .slip-board{margin-bottom:32px;}
  .slip-board-head{padding:16px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:var(--deep);border:1px solid var(--border);}
  .slip-board-head h3{font-size:13px;color:var(--foam);font-weight:500;}
  .slip-legend{display:flex;gap:16px;}
  .legend-item{display:flex;align-items:center;gap:6px;font-size:10px;color:var(--muted);}
  .legend-dot{width:8px;height:8px;border-radius:50%;}
  .slip-grid-wrap{background:var(--deep);border:1px solid var(--border);border-top:none;padding:20px 24px;}
  .slip-grid{display:grid;grid-template-columns:repeat(10,1fr);gap:6px;}
  @media(max-width:700px){.slip-grid{grid-template-columns:repeat(5,1fr);}}
  .slip-cell{aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:500;cursor:pointer;transition:opacity 0.2s;border:1px solid transparent;}
  .slip-occupied{background:rgba(201,168,76,0.2);border-color:rgba(201,168,76,0.3);color:var(--gold);}
  .slip-available{background:rgba(74,222,128,0.1);border-color:rgba(74,222,128,0.2);color:rgba(74,222,128,0.7);}
  .slip-reserved{background:rgba(245,158,11,0.12);border-color:rgba(245,158,11,0.2);color:#f59e0b;}
  .slip-maintenance{background:rgba(255,99,99,0.1);border-color:rgba(255,99,99,0.2);color:rgba(255,130,130,0.7);}
  .slip-cell:hover{opacity:0.75;}

  /* SWEEP WIDGET */
  .sweep-widget{background:var(--deep);border:1px solid var(--border);padding:24px;margin-bottom:32px;}
  .sweep-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;}
  .sweep-header h3{font-size:13px;color:var(--foam);font-weight:500;}
  .sweep-status{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;padding:4px 10px;background:rgba(74,222,128,0.1);color:var(--positive);border:1px solid rgba(74,222,128,0.2);}
  .sweep-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);}
  .sweep-row:last-child{border-bottom:none;}
  .sweep-label{font-size:12px;color:var(--muted);}
  .sweep-value{font-size:13px;color:var(--foam);}
  .sweep-value.highlight{font-family:'Playfair Display',serif;font-size:20px;color:var(--gold);}
  .btn-trigger-sweep{background:var(--gold);color:var(--ink);border:none;padding:12px 24px;font-size:11px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;margin-top:16px;width:100%;}
  .btn-trigger-sweep:hover{background:var(--goldlt);}
`;

const slipStatus = Array.from({ length: 106 }, (_, i) => {
  const r = Math.random();
  return r < 0.45 ? "occupied" : r < 0.7 ? "available" : r < 0.85 ? "reserved" : "maintenance";
});

const manifest = [
  { time: "07:00", name: "James Morrison · Sea Spirit", experience: "Dock arrival — 52ft", guests: "—", status: "occupied" },
  { time: "08:30", name: "Snorkel Tour — Group A", experience: "Living Reef · Island Runner", guests: "8 guests", status: "upcoming" },
  { time: "10:00", name: "Half-Day Fishing", experience: "Deep Sea · Marlin Queen", guests: "4 guests", status: "upcoming" },
  { time: "14:00", name: "Private Charter", experience: "Island Transit · Sand Dollar", guests: "6 guests", status: "reserved" },
  { time: "17:30", name: "Sunset Cruise", experience: "Harbour Route · Sand Dollar", guests: "12 guests", status: "upcoming" },
];

const payments = [
  { icon: "💳", name: "James Morrison — Sunset Cruise", meta: "Today · Card ••4821", amount: "+$537.60", dir: "in" as const },
  { icon: "⚡", name: "Island Runner — Fuel Top-Up", meta: "Today · Internal", amount: "−$180.00", dir: "out" as const },
  { icon: "💳", name: "Rodriguez Party — Full Day Charter", meta: "Yesterday · PayPal", amount: "+$1,045.00", dir: "in" as const },
  { icon: "🌙", name: "Daily Sweep — RBC ••4821", meta: "Yesterday 23:00 · Auto-sweep", amount: "+$3,220.40", dir: "in" as const },
];

export default function OperatorDashboard() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [activeNav, setActiveNav] = useState(0);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".kpi", { y: 20, opacity: 0, stagger: 0.06, duration: 0.7, ease: "power3.out", delay: 0.2 });
      gsap.from(".panel, .slip-board, .sweep-widget", { y: 30, opacity: 0, stagger: 0.1, duration: 0.9, ease: "power3.out", delay: 0.4 });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  const navSections = [
    { label: null, items: [{ icon: "⊞", label: "Today", badge: null }, { icon: "📅", label: "Bookings", badge: "3" }, { icon: "⚓", label: "Slip Board", badge: null }] },
    { label: "Finance", items: [{ icon: "💰", label: "Payments", badge: null }, { icon: "📊", label: "Reports", badge: null }, { icon: "🧾", label: "VAT Filing", badge: "1" }] },
    { label: "Operations", items: [{ icon: "⛵", label: "Fleet", badge: null }, { icon: "📋", label: "Waivers", badge: null }, { icon: "🔔", label: "Notifications", badge: "5" }] },
    { label: "Settings", items: [{ icon: "⚙", label: "Account", badge: null }] },
  ];

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <div className="ops-layout">
        <div className="ops-sidebar">
          <div className="sidebar-brand">
            <p className="sidebar-brand-top">PORT LUCAYA<span>.</span></p>
            <p className="sidebar-brand-sub">Operator Dashboard</p>
          </div>
          <div className="ops-nav">
            {navSections.map((section, si) => (
              <div key={si}>
                {section.label && <p className="ops-nav-section">{section.label}</p>}
                {section.items.map((item, ii) => {
                  const idx = navSections.slice(0, si).reduce((a, s) => a + s.items.length, 0) + ii;
                  return (
                    <div key={ii} className={`ops-nav-item${activeNav === idx ? " active" : ""}`} onClick={() => setActiveNav(idx)}>
                      <span className="ops-nav-icon">{item.icon}</span>
                      {item.label}
                      {item.badge && <span className="ops-nav-badge">{item.badge}</span>}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        <div className="ops-main">
          <div className="ops-topbar">
            <div className="ops-topbar-left">
              <h2>Good morning, Port Lucaya</h2>
              <p>Monday, 9 March 2026 · 5 departures today · Winds 12kt ESE</p>
            </div>
            <div className="ops-topbar-right">
              <span className="ops-date">09 Mar 2026</span>
              <div className="ops-alert-bell">🔔<div className="bell-dot" /></div>
            </div>
          </div>

          <div className="kpi-strip">
            {[
              { label: "Today's Revenue", val: "$3,840", delta: "+12%", up: true },
              { label: "MRR", val: "$28.4k", delta: "+8%", up: true },
              { label: "Slips Occupied", val: "48/106", delta: "45%", up: true },
              { label: "Departures Today", val: "5", delta: "On schedule", up: true },
              { label: "Pending Waivers", val: "3", delta: "Action needed", up: false },
            ].map((k) => (
              <div key={k.label} className="kpi">
                <span className="kpi-label">{k.label}</span>
                <p className="kpi-val">{k.val}</p>
                <p className={`kpi-delta ${k.up ? "delta-up" : "delta-down"}`}>{k.delta}</p>
              </div>
            ))}
          </div>

          <div className="dash-grid">
            <div className="panel">
              <div className="panel-head">
                <h3>Today&apos;s Manifest</h3>
                <button className="panel-head-action">View All</button>
              </div>
              <div className="manifest-list">
                {manifest.map((m, i) => (
                  <div key={i} className="manifest-row">
                    <span className="manifest-time">{m.time}</span>
                    <div>
                      <p className="manifest-name">{m.name}</p>
                      <p className="manifest-experience">{m.experience}</p>
                    </div>
                    <span style={{ fontSize: 11, color: "var(--muted)", whiteSpace: "nowrap" }}>{m.guests}</span>
                    <div className="manifest-dot" style={{ background: m.status === "occupied" ? "var(--gold)" : m.status === "upcoming" ? "var(--positive)" : "var(--warn)" }} />
                  </div>
                ))}
              </div>
            </div>

            <div className="panel">
              <div className="panel-head">
                <h3>Recent Payments</h3>
                <button className="panel-head-action">View All</button>
              </div>
              <div className="payment-list">
                {payments.map((p, i) => (
                  <div key={i} className="payment-row">
                    <span className="payment-icon">{p.icon}</span>
                    <div className="payment-info">
                      <p className="payment-info-name">{p.name}</p>
                      <p className="payment-info-meta">{p.meta}</p>
                    </div>
                    <span className={`payment-amount ${p.dir === "in" ? "amount-in" : "amount-out"}`}>{p.amount}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* SLIP BOARD */}
          <div className="slip-board">
            <div className="slip-board-head">
              <h3>Slip Board — 106 Berths</h3>
              <div className="slip-legend">
                {[{ color: "rgba(201,168,76,0.5)", label: "Occupied" }, { color: "rgba(74,222,128,0.5)", label: "Available" }, { color: "rgba(245,158,11,0.5)", label: "Reserved" }, { color: "rgba(255,99,99,0.5)", label: "Maintenance" }].map((l) => (
                  <div key={l.label} className="legend-item"><div className="legend-dot" style={{ background: l.color }} />{l.label}</div>
                ))}
              </div>
            </div>
            <div className="slip-grid-wrap">
              <div className="slip-grid">
                {slipStatus.map((status, i) => (
                  <div key={i} className={`slip-cell slip-${status}`}>{i + 1}</div>
                ))}
              </div>
            </div>
          </div>

          {/* SWEEP */}
          <div className="sweep-widget">
            <div className="sweep-header">
              <h3>Daily Sweep Engine</h3>
              <span className="sweep-status">Auto · Active</span>
            </div>
            {[
              { label: "Pending Balance", value: "$3,840.00", highlight: true },
              { label: "Last Sweep", value: "Yesterday 23:00 AST · $3,220.40" },
              { label: "Destination Account", value: "RBC Royal Bank ••4821" },
              { label: "Next Auto-Sweep", value: "Tonight 23:00 AST" },
              { label: "VAT Reserve (12%)", value: "$460.80 · Held for filing" },
            ].map((r) => (
              <div key={r.label} className="sweep-row">
                <span className="sweep-label">{r.label}</span>
                <span className={`sweep-value${r.highlight ? " highlight" : ""}`}>{r.value}</span>
              </div>
            ))}
            <button className="btn-trigger-sweep">Trigger Manual Sweep</button>
          </div>
        </div>
      </div>
    </div>
  );
}
