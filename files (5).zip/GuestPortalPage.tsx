"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}

  /* PORTAL LAYOUT */
  .portal-layout{display:grid;grid-template-columns:280px 1fr;min-height:100vh;}
  @media(max-width:900px){.portal-layout{grid-template-columns:1fr;}}
  .portal-sidebar{background:var(--deep);border-right:1px solid var(--border);padding:40px 32px;display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto;}
  .portal-main{padding:40px 48px;overflow-y:auto;}

  /* SIDEBAR */
  .portal-brand{margin-bottom:48px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .portal-brand p{font-size:11px;color:var(--muted);margin-top:4px;letter-spacing:0.08em;}

  .portal-user{padding:20px;background:rgba(201,168,76,0.05);border:1px solid rgba(201,168,75,0.15);margin-bottom:40px;}
  .user-avatar{width:40px;height:40px;border-radius:50%;background:rgba(201,168,76,0.2);border:1px solid rgba(201,168,76,0.4);display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-size:16px;color:var(--gold);margin-bottom:12px;}
  .user-name{font-size:15px;color:var(--white);font-weight:500;margin-bottom:2px;}
  .user-email{font-size:11px;color:var(--muted);}

  .sidebar-nav{display:flex;flex-direction:column;gap:2px;flex:1;}
  .sidebar-nav-item{display:flex;align-items:center;gap:14px;padding:14px 16px;font-size:13px;color:var(--muted);cursor:pointer;border:1px solid transparent;transition:all 0.3s;letter-spacing:0.04em;}
  .sidebar-nav-item:hover{color:var(--foam);background:rgba(255,255,255,0.03);border-color:var(--border);}
  .sidebar-nav-item.active{color:var(--gold);background:rgba(201,168,76,0.06);border-color:rgba(201,168,75,0.2);}
  .nav-icon{font-size:16px;opacity:0.8;}
  .sidebar-sign-out{margin-top:auto;padding-top:24px;border-top:1px solid var(--border);}
  .sign-out-btn{width:100%;background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Outfit',sans-serif;font-size:11px;letter-spacing:0.12em;text-transform:uppercase;padding:12px;cursor:pointer;transition:all 0.3s;}
  .sign-out-btn:hover{border-color:rgba(255,80,80,0.4);color:rgba(255,120,120,0.8);}

  /* MAIN */
  .portal-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:48px;padding-bottom:32px;border-bottom:1px solid var(--border);}
  .portal-greeting h2{font-family:'Playfair Display',serif;font-size:32px;color:var(--white);}
  .portal-greeting h2 em{font-style:italic;color:var(--gold);}
  .portal-greeting p{font-size:13px;color:var(--muted);margin-top:4px;}
  .btn-new-booking{background:var(--gold);color:var(--ink);border:none;padding:14px 28px;font-size:11px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;}
  .btn-new-booking:hover{background:var(--goldlt);}

  /* STATS ROW */
  .stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;margin-bottom:48px;}
  @media(max-width:700px){.stats-row{grid-template-columns:repeat(2,1fr);}}
  .stat-card{background:var(--deep);border:1px solid var(--border);padding:24px 28px;}
  .stat-card-label{font-size:10px;text-transform:uppercase;letter-spacing:0.16em;color:var(--muted);margin-bottom:8px;display:block;}
  .stat-card-val{font-family:'Playfair Display',serif;font-size:32px;color:var(--gold);font-weight:700;}
  .stat-card-sub{font-size:11px;color:var(--muted);margin-top:4px;}

  /* BOOKINGS */
  .section-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
  .section-head h3{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);}
  .section-head h3 em{font-style:italic;color:var(--gold);}
  .view-all{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.14em;cursor:pointer;background:none;border:none;transition:opacity 0.3s;}
  .view-all:hover{opacity:0.7;}

  .booking-list{display:flex;flex-direction:column;gap:2px;margin-bottom:48px;}
  .booking-row{background:var(--deep);border:1px solid var(--border);padding:24px 32px;display:grid;grid-template-columns:auto 1fr auto auto;gap:20px;align-items:center;transition:border-color 0.3s;}
  .booking-row:hover{border-color:rgba(201,168,75,0.25);}
  .booking-status-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
  .status-upcoming{background:#c9a84c;}
  .status-completed{background:rgba(74,222,128,0.7);}
  .status-cancelled{background:rgba(255,99,99,0.7);}
  .booking-name{font-size:15px;color:var(--foam);font-weight:500;margin-bottom:4px;}
  .booking-date{font-size:12px;color:var(--muted);}
  .booking-amount{font-family:'Playfair Display',serif;font-size:20px;color:var(--gold);text-align:right;}
  .booking-action{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:0.1em;cursor:pointer;transition:color 0.3s;background:none;border:none;}
  .booking-action:hover{color:var(--gold);}
  .booking-badge{font-size:9px;text-transform:uppercase;letter-spacing:0.14em;padding:3px 8px;border:1px solid;white-space:nowrap;}
  .badge-upcoming{border-color:rgba(201,168,76,0.4);color:var(--gold);}
  .badge-completed{border-color:rgba(74,222,128,0.3);color:rgba(74,222,128,0.9);}
  .badge-cancelled{border-color:rgba(255,99,99,0.3);color:rgba(255,130,130,0.8);}

  /* VESSEL CARD */
  .vessel-card{background:var(--deep);border:1px solid var(--border);padding:32px;display:grid;grid-template-columns:1fr auto;gap:24px;align-items:start;margin-bottom:48px;}
  .vessel-card-name{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);margin-bottom:4px;}
  .vessel-card-type{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:16px;display:block;}
  .vessel-specs{display:flex;gap:24px;flex-wrap:wrap;}
  .vessel-spec span{font-size:10px;color:var(--muted);text-transform:uppercase;display:block;margin-bottom:3px;}
  .vessel-spec p{font-size:14px;color:var(--foam);}
  .btn-edit-vessel{background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Outfit',sans-serif;font-size:11px;letter-spacing:0.1em;text-transform:uppercase;padding:10px 20px;cursor:pointer;transition:all 0.3s;white-space:nowrap;}
  .btn-edit-vessel:hover{border-color:var(--gold);color:var(--gold);}

  /* EMPTY */
  .empty-state{padding:60px;text-align:center;border:1px solid var(--border);background:var(--deep);}
  .empty-icon{font-size:40px;margin-bottom:16px;opacity:0.4;}
  .empty-title{font-family:'Playfair Display',serif;font-size:22px;color:var(--muted);margin-bottom:8px;}
  .empty-sub{font-size:13px;color:rgba(232,244,248,0.3);}
`;

const bookings = [
  { name: "Sunset Harbour Cruise", date: "Sat, 14 March 2026 · 17:30", amount: "$537.60", status: "upcoming" as const },
  { name: "Deep Sea Fishing Charter", date: "Sun, 02 February 2026", amount: "$1,045.00", status: "completed" as const },
  { name: "Snorkel & Reef Tour", date: "Fri, 20 December 2025", amount: "$340.00", status: "completed" as const },
  { name: "Kayak Hire — Half Day", date: "Sat, 14 December 2025", amount: "$60.00", status: "cancelled" as const },
];

const navItems = [
  { icon: "⊞", label: "Overview" },
  { icon: "⚓", label: "My Bookings" },
  { icon: "⛵", label: "My Vessel" },
  { icon: "📄", label: "Documents" },
  { icon: "💳", label: "Payments" },
  { icon: "⚙", label: "Settings" },
];

export default function GuestPortalPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [activeNav, setActiveNav] = useState(0);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".portal-user, .sidebar-nav-item", { x: -20, opacity: 0, stagger: 0.06, duration: 0.8, ease: "power3.out" });
      gsap.from(".portal-topbar, .stats-row, .booking-list, .vessel-card", { y: 30, opacity: 0, stagger: 0.12, duration: 0.9, ease: "power3.out", delay: 0.2 });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <div className="portal-layout">
        {/* SIDEBAR */}
        <div className="portal-sidebar">
          <div className="portal-brand">
            <div className="nav-logo">PORT LUCAYA<span>.</span></div>
            <p>Guest Portal</p>
          </div>
          <div className="portal-user">
            <div className="user-avatar">J</div>
            <p className="user-name">James Morrison</p>
            <p className="user-email">captain@vessel.com</p>
          </div>
          <div className="sidebar-nav">
            {navItems.map((item, i) => (
              <div key={i} className={`sidebar-nav-item${activeNav === i ? " active" : ""}`} onClick={() => setActiveNav(i)}>
                <span className="nav-icon">{item.icon}</span>
                {item.label}
              </div>
            ))}
          </div>
          <div className="sidebar-sign-out">
            <button className="sign-out-btn">Sign Out</button>
          </div>
        </div>

        {/* MAIN */}
        <div className="portal-main">
          <div className="portal-topbar">
            <div className="portal-greeting">
              <h2>Welcome back, <em>James</em></h2>
              <p>Monday, 9 March 2026 · Grand Bahama, 82°F</p>
            </div>
            <button className="btn-new-booking" onClick={() => window.location.href = "/book"}>+ New Booking</button>
          </div>

          <div className="stats-row">
            {[
              { label: "Total Bookings", val: "8", sub: "4 this season" },
              { label: "Next Experience", val: "5d", sub: "14 March 2026" },
              { label: "Balance Due", val: "$268", sub: "Due on arrival" },
              { label: "Waivers Signed", val: "3/3", sub: "All current" },
            ].map((s) => (
              <div key={s.label} className="stat-card">
                <span className="stat-card-label">{s.label}</span>
                <div className="stat-card-val">{s.val}</div>
                <p className="stat-card-sub">{s.sub}</p>
              </div>
            ))}
          </div>

          {/* UPCOMING */}
          <div className="section-head">
            <h3>My <em>Bookings</em></h3>
            <button className="view-all">View All</button>
          </div>
          <div className="booking-list">
            {bookings.map((b, i) => (
              <div key={i} className="booking-row">
                <div className={`booking-status-dot status-${b.status}`} />
                <div>
                  <p className="booking-name">{b.name}</p>
                  <p className="booking-date">{b.date}</p>
                </div>
                <span className={`booking-badge badge-${b.status}`}>{b.status}</span>
                <div style={{ textAlign: "right" }}>
                  <p className="booking-amount">{b.amount}</p>
                  <button className="booking-action">Details →</button>
                </div>
              </div>
            ))}
          </div>

          {/* VESSEL */}
          <div className="section-head">
            <h3>My <em>Vessel</em></h3>
            <button className="view-all">Edit</button>
          </div>
          <div className="vessel-card">
            <div>
              <span className="vessel-card-type">52′ Sportfisher</span>
              <p className="vessel-card-name">Sea Spirit</p>
              <div className="vessel-specs">
                {[
                  { label: "LOA", val: "52 ft" },
                  { label: "Draft", val: "6 ft" },
                  { label: "Flag", val: "USA" },
                  { label: "MMSI", val: "338xxxxxx" },
                ].map((v) => (
                  <div key={v.label} className="vessel-spec">
                    <span>{v.label}</span>
                    <p>{v.val}</p>
                  </div>
                ))}
              </div>
            </div>
            <button className="btn-edit-vessel">Edit Vessel</button>
          </div>
        </div>
      </div>
    </div>
  );
}
