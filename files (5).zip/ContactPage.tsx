"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--steel:#1e3a5f;--horizon:#2d5a8e;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}
  .reveal{opacity:0;}
  .plm-nav{position:fixed;top:0;left:0;right:0;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:32px 48px;transition:background 0.4s,backdrop-filter 0.4s,padding 0.4s;}
  .plm-nav.scrolled{background:rgba(8,12,20,0.88);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:18px 48px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .nav-links{display:flex;gap:40px;list-style:none;}
  .nav-links a{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.14em;text-transform:uppercase;transition:color 0.3s;}
  .nav-links a:hover,.nav-links a.active{color:var(--gold);}
  .nav-cta{background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Outfit',sans-serif;font-size:11px;font-weight:500;letter-spacing:0.12em;text-transform:uppercase;padding:12px 28px;cursor:pointer;transition:all 0.3s;}
  .nav-cta:hover{background:var(--gold);color:var(--ink);}

  .contact-hero{min-height:60vh;padding:180px 48px 80px;background:linear-gradient(160deg,var(--deep) 0%,var(--ink) 60%);border-bottom:1px solid var(--border);display:flex;align-items:flex-end;}
  .page-hero-label{display:flex;align-items:center;gap:16px;margin-bottom:28px;}
  .label-line{width:48px;height:1px;background:var(--gold);}
  .label-text{font-size:11px;font-weight:500;color:var(--gold);letter-spacing:0.22em;text-transform:uppercase;}
  .contact-hero h1{font-family:'Playfair Display',serif;font-size:clamp(52px,8vw,96px);font-weight:900;color:var(--white);line-height:0.9;letter-spacing:-0.02em;}
  .contact-hero h1 em{font-style:italic;color:var(--gold);font-weight:400;}
  .contact-hero p{font-size:18px;font-weight:300;color:var(--muted);line-height:1.7;max-width:540px;margin-top:24px;}

  /* CONTACT GRID */
  .contact-section{padding:100px 48px 160px;}
  .contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;max-width:1300px;margin:0 auto;}
  @media(max-width:900px){.contact-grid{grid-template-columns:1fr;}}

  /* INFO */
  .contact-info-head{font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,48px);color:var(--white);margin-bottom:12px;}
  .contact-info-head em{font-style:italic;color:var(--gold);}
  .contact-info-sub{font-size:15px;color:var(--muted);line-height:1.75;margin-bottom:56px;}
  .contact-info-blocks{display:flex;flex-direction:column;gap:2px;margin-bottom:56px;}
  .info-block{padding:28px 32px;background:var(--deep);border:1px solid var(--border);transition:border-color 0.3s;}
  .info-block:hover{border-color:rgba(201,168,76,0.3);}
  .info-block-label{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:8px;display:block;}
  .info-block-value{font-size:15px;color:var(--foam);line-height:1.6;}
  .info-block-value a{color:var(--foam);text-decoration:none;transition:color 0.3s;}
  .info-block-value a:hover{color:var(--gold);}
  .hours-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
  .hour-item span{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.14em;display:block;margin-bottom:4px;}
  .hour-item p{font-size:14px;color:var(--foam);}

  /* FORM */
  .contact-form-wrap{background:var(--deep);border:1px solid var(--border);padding:64px;}
  .form-head{margin-bottom:48px;}
  .form-head h3{font-family:'Playfair Display',serif;font-size:32px;color:var(--white);margin-bottom:10px;}
  .form-head p{font-size:14px;color:var(--muted);line-height:1.7;}
  .form-row{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
  @media(max-width:600px){.form-row{grid-template-columns:1fr;}}
  .input-group{margin-bottom:20px;}
  .input-label{font-size:10px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);margin-bottom:8px;display:block;}
  .input-field{width:100%;background:rgba(255,255,255,0.03);border:1px solid var(--border);padding:16px 18px;color:var(--white);font-family:'Outfit',sans-serif;font-size:14px;transition:border-color 0.3s;resize:none;}
  .input-field:focus{border-color:var(--gold);outline:none;background:rgba(201,168,76,0.03);}
  .input-field::placeholder{color:rgba(232,244,248,0.2);}
  select.input-field option{background:var(--deep);}
  .btn-submit{background:var(--gold);color:var(--ink);border:none;padding:20px 48px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;margin-top:8px;}
  .btn-submit:hover{background:var(--goldlt);transform:translateY(-2px);box-shadow:0 8px 24px rgba(201,168,76,0.25);}
  .success-state{text-align:center;padding:60px 0;}
  .success-icon{font-size:48px;margin-bottom:24px;}
  .success-title{font-family:'Playfair Display',serif;font-size:32px;color:var(--gold);margin-bottom:12px;}
  .success-body{font-size:15px;color:var(--muted);line-height:1.7;}

  /* MAP PLACEHOLDER */
  .map-section{background:#060a14;border-top:1px solid var(--border);}
  .map-placeholder{height:400px;background:linear-gradient(135deg,#080c14 0%,#0a1628 100%);display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;}
  .map-label{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;}
  .map-label h4{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);margin-bottom:8px;}
  .map-label p{font-size:13px;color:var(--muted);}
  .map-pin{width:16px;height:16px;background:var(--gold);border-radius:50% 50% 50% 0;transform:rotate(-45deg);margin:0 auto 16px;}
  .coordinates{display:flex;gap:48px;justify-content:center;padding:32px 48px;background:var(--deep);border-top:1px solid var(--border);}
  .coord-item span{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;display:block;margin-bottom:4px;}
  .coord-item p{font-size:14px;color:var(--foam);}

  footer{padding:80px 48px;border-top:1px solid var(--border);text-align:center;}
  .footer-text{font-size:12px;color:var(--muted);letter-spacing:0.08em;}
  .footer-text span{color:var(--gold);}
`;

export default function ContactPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [sent, setSent] = useState(false);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".contact-hero > * > *, .contact-hero > *", { y: 50, opacity: 0, stagger: 0.15, duration: 1.2, ease: "power4.out" });
      const reveals = gsap.utils.toArray<HTMLElement>(".reveal");
      reveals.forEach(el => {
        gsap.fromTo(el, { y: 50, opacity: 0 }, { scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" }, y: 0, opacity: 1, duration: 1.1, ease: "power3.out" });
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>

      <nav className="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="contact-hero">
        <div>
          <div className="page-hero-label"><div className="label-line" /><span className="label-text">Freeport, The Bahamas</span></div>
          <h1>Get in <em>Touch</em></h1>
          <p>Whether you&apos;re planning a transatlantic passage or just need a slip for the night — we&apos;re here. Our dock staff respond within 2 hours during marina hours.</p>
        </div>
      </section>

      <section className="contact-section">
        <div className="contact-grid">
          <div>
            <h2 className="contact-info-head reveal">Marina <em>Information</em></h2>
            <p className="contact-info-sub reveal">Port of Entry · 106 Slips · 190ft Max LOA · Lat 26.51367 · Long -78.64185</p>
            <div className="contact-info-blocks">
              {[
                { label: "Phone", value: <a href="tel:+12423739090">(242) 373-9090</a> },
                { label: "Email", value: <a href="mailto:info@portlucayamarina.com">info@portlucayamarina.com</a> },
                { label: "Address", value: <span>Port Lucaya Marina<br />Freeport, Grand Bahama<br />The Bahamas</span> },
              ].map((b, i) => (
                <div key={i} className="info-block reveal">
                  <span className="info-block-label">{b.label}</span>
                  <div className="info-block-value">{b.value}</div>
                </div>
              ))}
              <div className="info-block reveal">
                <span className="info-block-label">Marina Hours</span>
                <div className="hours-grid">
                  <div className="hour-item"><span>Mon – Fri</span><p>07:00 – 20:00</p></div>
                  <div className="hour-item"><span>Sat – Sun</span><p>06:00 – 22:00</p></div>
                  <div className="hour-item"><span>Fuel Dock</span><p>07:00 – 18:00</p></div>
                  <div className="hour-item"><span>Customs</span><p>08:00 – 17:00</p></div>
                </div>
              </div>
            </div>
          </div>

          <div className="contact-form-wrap reveal">
            {sent ? (
              <div className="success-state">
                <div className="success-icon">⚓</div>
                <h3 className="success-title">Message Received</h3>
                <p className="success-body">Our dock team will respond within 2 hours during marina hours. For urgent matters, call us directly at (242) 373-9090.</p>
              </div>
            ) : (
              <>
                <div className="form-head">
                  <h3>Send a Message</h3>
                  <p>For slip reservations, charter enquiries, or general questions about the marina.</p>
                </div>
                <form onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
                  <div className="form-row">
                    <div className="input-group">
                      <label className="input-label">First Name</label>
                      <input className="input-field" placeholder="James" required />
                    </div>
                    <div className="input-group">
                      <label className="input-label">Last Name</label>
                      <input className="input-field" placeholder="Morrison" required />
                    </div>
                  </div>
                  <div className="input-group">
                    <label className="input-label">Email Address</label>
                    <input className="input-field" type="email" placeholder="captain@vessel.com" required />
                  </div>
                  <div className="input-group">
                    <label className="input-label">Enquiry Type</label>
                    <select className="input-field">
                      <option value="">Select enquiry type</option>
                      <option>Slip Reservation</option>
                      <option>Charter Booking</option>
                      <option>Port of Entry / Customs</option>
                      <option>Vessel Services</option>
                      <option>General Enquiry</option>
                    </select>
                  </div>
                  <div className="input-group">
                    <label className="input-label">Vessel Length (ft)</label>
                    <input className="input-field" placeholder="e.g. 52" />
                  </div>
                  <div className="input-group">
                    <label className="input-label">Message</label>
                    <textarea className="input-field" rows={5} placeholder="Tell us your planned arrival date, vessel details, or how we can help..." required />
                  </div>
                  <button type="submit" className="btn-submit">Send Message</button>
                </form>
              </>
            )}
          </div>
        </div>
      </section>

      <div className="map-section">
        <div className="map-placeholder">
          <svg viewBox="0 0 800 400" fill="none" width="100%" height="100%" style={{ position: "absolute", inset: 0 }} opacity={0.06}>
            {Array.from({ length: 12 }).map((_, i) => (
              <line key={i} x1={i * 70} y1={0} x2={i * 70} y2={400} stroke="#c9a84c" strokeWidth="0.5"/>
            ))}
            {Array.from({ length: 8 }).map((_, i) => (
              <line key={i} x1={0} y1={i * 55} x2={800} y2={i * 55} stroke="#c9a84c" strokeWidth="0.5"/>
            ))}
          </svg>
          <div className="map-label">
            <div className="map-pin"/>
            <h4>Port Lucaya Marina</h4>
            <p>Freeport, Grand Bahama Island</p>
          </div>
        </div>
        <div className="coordinates">
          <div className="coord-item"><span>Latitude</span><p>26° 30′ 49″ N</p></div>
          <div className="coord-item"><span>Longitude</span><p>78° 38′ 31″ W</p></div>
          <div className="coord-item"><span>VHF Channel</span><p>Ch. 16 / Ch. 68</p></div>
          <div className="coord-item"><span>MMSI</span><p>311001234</p></div>
        </div>
      </div>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
