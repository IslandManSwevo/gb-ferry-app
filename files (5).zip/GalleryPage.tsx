"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root { --ink:#080c14;--deep:#0a1628;--navy:#0f2044;--steel:#1e3a5f;--horizon:#2d5a8e;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10); background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh; }
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}
  .reveal{opacity:0;}

  .plm-nav{position:fixed;top:0;left:0;right:0;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:32px 48px;transition:background 0.4s,backdrop-filter 0.4s,padding 0.4s;}
  .plm-nav.scrolled{background:rgba(8,12,20,0.88);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:18px 48px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--white);letter-spacing:0.02em;}
  .nav-logo span{color:var(--gold);}
  .nav-links{display:flex;gap:40px;list-style:none;}
  .nav-links a{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.14em;text-transform:uppercase;transition:color 0.3s;}
  .nav-links a:hover,.nav-links a.active{color:var(--gold);}
  .nav-cta{background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Outfit',sans-serif;font-size:11px;font-weight:500;letter-spacing:0.12em;text-transform:uppercase;padding:12px 28px;cursor:pointer;transition:all 0.3s;}
  .nav-cta:hover{background:var(--gold);color:var(--ink);}

  .page-hero{padding:180px 48px 100px;background:linear-gradient(160deg,var(--deep) 0%,var(--ink) 60%);border-bottom:1px solid var(--border);}
  .page-hero-label{display:flex;align-items:center;gap:16px;margin-bottom:28px;}
  .label-line{width:48px;height:1px;background:var(--gold);}
  .label-text{font-size:11px;font-weight:500;color:var(--gold);letter-spacing:0.22em;text-transform:uppercase;}
  .page-hero h1{font-family:'Playfair Display',serif;font-size:clamp(52px,8vw,96px);font-weight:900;color:var(--white);line-height:0.9;letter-spacing:-0.02em;}
  .page-hero h1 em{font-style:italic;color:var(--gold);font-weight:400;}
  .page-hero p{font-size:18px;font-weight:300;color:var(--muted);line-height:1.7;max-width:560px;margin-top:28px;}

  .filter-bar{padding:32px 48px;background:var(--deep);border-bottom:1px solid var(--border);display:flex;gap:8px;flex-wrap:wrap;}
  .filter-btn{background:transparent;border:1px solid var(--border);color:var(--muted);font-family:'Outfit',sans-serif;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;padding:10px 20px;cursor:pointer;transition:all 0.3s;}
  .filter-btn:hover,.filter-btn.active{border-color:var(--gold);color:var(--gold);background:rgba(201,168,76,0.06);}

  .gallery-section{padding:80px 48px 140px;}
  .gallery-masonry{columns:3 300px;gap:4px;}
  @media(max-width:768px){.gallery-masonry{columns:2;}}
  @media(max-width:480px){.gallery-masonry{columns:1;}}

  .gallery-item{break-inside:avoid;margin-bottom:4px;position:relative;overflow:hidden;cursor:pointer;display:block;}
  .gallery-item:hover .gallery-overlay{opacity:1;}
  .gallery-item:hover .gallery-img{transform:scale(1.05);}
  .gallery-img{width:100%;display:block;transition:transform 0.6s cubic-bezier(0.23,1,0.32,1);}
  .gallery-placeholder{width:100%;background:var(--deep);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;transition:transform 0.6s cubic-bezier(0.23,1,0.32,1);}
  .gallery-overlay{position:absolute;inset:0;background:linear-gradient(to top,rgba(8,12,20,0.8) 0%,transparent 50%);opacity:0;transition:opacity 0.4s;display:flex;align-items:flex-end;padding:24px;}
  .gallery-overlay-content{}
  .gallery-tag{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:6px;display:block;}
  .gallery-title{font-family:'Playfair Display',serif;font-size:20px;color:var(--white);}

  /* LIGHTBOX */
  .lightbox{position:fixed;inset:0;z-index:1000;background:rgba(8,12,20,0.97);display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
  .lightbox-inner{position:relative;max-width:90vw;max-height:90vh;}
  .lightbox-img{max-width:100%;max-height:80vh;object-fit:contain;}
  .lightbox-placeholder{width:min(700px,90vw);display:flex;align-items:center;justify-content:center;background:var(--deep);border:1px solid var(--border);}
  .lightbox-close{position:absolute;top:-48px;right:0;background:none;border:none;color:var(--foam);cursor:pointer;font-size:28px;line-height:1;transition:color 0.3s;}
  .lightbox-close:hover{color:var(--gold);}
  .lightbox-meta{padding:20px 0 0;}
  .lightbox-tag{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:6px;display:block;}
  .lightbox-title{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);}
  .lightbox-nav{position:absolute;top:50%;transform:translateY(-50%);background:rgba(8,12,20,0.6);border:1px solid var(--border);color:var(--foam);width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.3s;font-size:20px;}
  .lightbox-nav:hover{border-color:var(--gold);color:var(--gold);}
  .lightbox-prev{left:-72px;}
  .lightbox-next{right:-72px;}

  footer{padding:80px 48px;border-top:1px solid var(--border);text-align:center;}
  .footer-text{font-size:12px;color:var(--muted);letter-spacing:0.08em;}
  .footer-text span{color:var(--gold);}
`;

const photos = [
  { category: "Marina", title: "Aerial View at Dawn", height: 280, bg: "linear-gradient(135deg,#0a1f3d,#0f2a4a)", aspect: 1.4 },
  { category: "Fishing", title: "Deep Sea Rigging", height: 380, bg: "linear-gradient(135deg,#081228,#0f1a38)", aspect: 0.75 },
  { category: "Charter", title: "Sunset Departure", height: 240, bg: "linear-gradient(135deg,#1a1408,#2a200a)", aspect: 1.6 },
  { category: "Marina", title: "Dock at Golden Hour", height: 340, bg: "linear-gradient(135deg,#0a1628,#152238)", aspect: 0.9 },
  { category: "Experiences", title: "Reef Snorkelling", height: 260, bg: "linear-gradient(135deg,#082a35,#0c3545)", aspect: 1.3 },
  { category: "Fishing", title: "Tournament Day", height: 320, bg: "linear-gradient(135deg,#0a1f3d,#1a2d40)", aspect: 0.85 },
  { category: "Charter", title: "Private Island Stop", height: 220, bg: "linear-gradient(135deg,#14100a,#1e1808)", aspect: 1.7 },
  { category: "Marina", title: "Fleet at Rest", height: 360, bg: "linear-gradient(135deg,#080c14,#0f1828)", aspect: 0.8 },
  { category: "Experiences", title: "Kayak Morning", height: 250, bg: "linear-gradient(135deg,#0a1a10,#0f2518)", aspect: 1.5 },
  { category: "Fishing", title: "Marlin Strike", height: 300, bg: "linear-gradient(135deg,#0a1f3d,#0f2044)", aspect: 1.0 },
  { category: "Charter", title: "Deck Life", height: 200, bg: "linear-gradient(135deg,#0d1a28,#1a2d40)", aspect: 1.8 },
  { category: "Marina", title: "Night Reflections", height: 420, bg: "linear-gradient(135deg,#060810,#080c18)", aspect: 0.7 },
];

const GalleryPlaceholder = ({ item }: { item: typeof photos[0] }) => (
  <div className="gallery-placeholder" style={{ height: item.height, background: item.bg }}>
    <svg viewBox="0 0 120 80" fill="none" width="60" opacity={0.2}>
      <rect x="10" y="15" width="100" height="65" rx="2" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
      <circle cx="38" cy="38" r="10" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
      <path d="M10 60 L35 38 L55 52 L75 35 L110 60" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
    </svg>
  </div>
);

export default function GalleryPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [lightbox, setLightbox] = useState<number | null>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".page-hero h1, .page-hero p, .page-hero-label", {
        y: 50, opacity: 0, stagger: 0.15, duration: 1.2, ease: "power4.out"
      });
      gsap.utils.toArray<HTMLElement>(".gallery-item").forEach((el, i) => {
        gsap.fromTo(el,
          { y: 40, opacity: 0 },
          { scrollTrigger: { trigger: el, start: "top 92%", toggleActions: "play none none none" },
            y: 0, opacity: 1, duration: 0.9, delay: (i % 3) * 0.08, ease: "power3.out" }
        );
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>

      {lightbox !== null && (
        <div className="lightbox" onClick={() => setLightbox(null)}>
          <div className="lightbox-inner" onClick={(e) => e.stopPropagation()}>
            <button className="lightbox-close" onClick={() => setLightbox(null)}>×</button>
            <button className="lightbox-nav lightbox-prev" onClick={() => setLightbox((lightbox - 1 + photos.length) % photos.length)}>‹</button>
            <div className="lightbox-placeholder" style={{ height: 480, background: photos[lightbox].bg, alignItems: "center", justifyContent: "center", display: "flex" }}>
              <svg viewBox="0 0 120 80" fill="none" width="80" opacity={0.2}>
                <rect x="10" y="15" width="100" height="65" rx="2" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
                <circle cx="38" cy="38" r="10" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
                <path d="M10 60 L35 38 L55 52 L75 35 L110 60" stroke="#c9a84c" strokeWidth="1.5" fill="none"/>
              </svg>
            </div>
            <button className="lightbox-nav lightbox-next" onClick={() => setLightbox((lightbox + 1) % photos.length)}>›</button>
            <div className="lightbox-meta">
              <span className="lightbox-tag">{photos[lightbox].category}</span>
              <p className="lightbox-title">{photos[lightbox].title}</p>
            </div>
          </div>
        </div>
      )}

      <nav className="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h} className={l === "Gallery" ? "active" : ""}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="page-hero">
        <div className="page-hero-label">
          <div className="label-line" />
          <span className="label-text">Life at Port Lucaya</span>
        </div>
        <h1>The <em>Gallery</em></h1>
        <p>A visual record of life on the water — from pre-dawn departures to golden-hour returns. Every image taken from our marina.</p>
      </section>

      <div className="filter-bar">
        {["All", "Marina", "Fishing", "Charter", "Experiences"].map((cat, i) => (
          <button key={cat} className={`filter-btn${i === 0 ? " active" : ""}`}>{cat}</button>
        ))}
      </div>

      <section className="gallery-section">
        <div className="gallery-masonry">
          {photos.map((photo, i) => (
            <div key={i} className="gallery-item" onClick={() => setLightbox(i)}>
              <GalleryPlaceholder item={photo} />
              <div className="gallery-overlay">
                <div className="gallery-overlay-content">
                  <span className="gallery-tag">{photo.category}</span>
                  <p className="gallery-title">{photo.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
