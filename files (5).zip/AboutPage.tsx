"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--steel:#1e3a5f;--horizon:#2d5a8e;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}
  .reveal{opacity:0;}
  .plm-nav{position:fixed;top:0;left:0;right:0;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:32px 48px;transition:background 0.4s,backdrop-filter 0.4s,padding 0.4s;}
  .plm-nav.scrolled{background:rgba(8,12,20,0.88);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:18px 48px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--white);}
  .nav-logo span{color:var(--gold);}
  .nav-links{display:flex;gap:40px;list-style:none;}
  .nav-links a{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.14em;text-transform:uppercase;transition:color 0.3s;}
  .nav-links a:hover,.nav-links a.active{color:var(--gold);}
  .nav-cta{background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Outfit',sans-serif;font-size:11px;font-weight:500;letter-spacing:0.12em;text-transform:uppercase;padding:12px 28px;cursor:pointer;transition:all 0.3s;}
  .nav-cta:hover{background:var(--gold);color:var(--ink);}

  /* SPLIT HERO */
  .about-hero{min-height:100vh;display:grid;grid-template-columns:1fr 1fr;}
  @media(max-width:768px){.about-hero{grid-template-columns:1fr;min-height:auto;}}
  .about-hero-copy{padding:180px 64px 100px;display:flex;flex-direction:column;justify-content:center;background:var(--deep);}
  .about-hero-visual{position:relative;overflow:hidden;background:linear-gradient(135deg,#0a1f3d 0%,#0f2a4a 50%,#152a4a 100%);min-height:500px;}
  .about-hero-visual-inner{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;}
  .page-hero-label{display:flex;align-items:center;gap:16px;margin-bottom:28px;}
  .label-line{width:48px;height:1px;background:var(--gold);}
  .label-text{font-size:11px;font-weight:500;color:var(--gold);letter-spacing:0.22em;text-transform:uppercase;}
  .about-hero-copy h1{font-family:'Playfair Display',serif;font-size:clamp(48px,7vw,88px);font-weight:900;color:var(--white);line-height:0.9;letter-spacing:-0.02em;margin-bottom:28px;}
  .about-hero-copy h1 em{font-style:italic;color:var(--gold);font-weight:400;}
  .about-hero-copy p{font-size:18px;font-weight:300;color:var(--muted);line-height:1.8;max-width:480px;}

  /* STORY */
  .story-section{padding:160px 48px;}
  .story-grid{display:grid;grid-template-columns:1fr 1fr;gap:120px;align-items:start;max-width:1400px;margin:0 auto;}
  @media(max-width:900px){.story-grid{grid-template-columns:1fr;gap:60px;}}
  .story-sticky{position:sticky;top:100px;}
  .story-label{display:flex;align-items:center;gap:16px;margin-bottom:28px;}
  .story-label-line{width:32px;height:1px;background:var(--gold);}
  .story-label-text{font-size:10px;font-weight:500;color:var(--gold);letter-spacing:0.22em;text-transform:uppercase;}
  .story-heading{font-family:'Playfair Display',serif;font-size:clamp(36px,5vw,64px);color:var(--white);line-height:1;margin-bottom:24px;}
  .story-heading em{font-style:italic;color:var(--gold);}
  .story-subtext{font-size:15px;color:var(--muted);line-height:1.8;}
  .story-chapters{display:flex;flex-direction:column;gap:64px;}
  .story-chapter{border-left:1px solid var(--border);padding-left:40px;position:relative;}
  .story-chapter::before{content:'';position:absolute;left:-5px;top:0;width:9px;height:9px;border-radius:50%;background:var(--gold);}
  .story-year{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:12px;display:block;}
  .story-chapter h3{font-family:'Playfair Display',serif;font-size:28px;color:var(--white);margin-bottom:16px;}
  .story-chapter p{font-size:15px;color:var(--muted);line-height:1.8;}

  /* TEAM */
  .team-section{padding:100px 48px 160px;background:#060a14;border-top:1px solid var(--border);}
  .team-head{margin-bottom:80px;}
  .team-head h2{font-family:'Playfair Display',serif;font-size:clamp(36px,5vw,64px);color:var(--white);}
  .team-head h2 em{font-style:italic;color:var(--gold);}
  .team-head p{font-size:15px;color:var(--muted);line-height:1.7;max-width:520px;margin-top:16px;}
  .team-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;}
  @media(max-width:768px){.team-grid{grid-template-columns:1fr;}}
  .team-card{background:var(--deep);border:1px solid var(--border);overflow:hidden;transition:border-color 0.4s;}
  .team-card:hover{border-color:rgba(201,168,76,0.35);}
  .team-avatar{height:240px;display:flex;align-items:center;justify-content:center;position:relative;}
  .team-body{padding:36px;}
  .team-name{font-family:'Playfair Display',serif;font-size:24px;color:var(--white);margin-bottom:6px;}
  .team-role{font-size:11px;color:var(--gold);text-transform:uppercase;letter-spacing:0.16em;margin-bottom:16px;display:block;}
  .team-bio{font-size:13px;color:var(--muted);line-height:1.75;}

  /* VALUES */
  .values-section{padding:100px 48px 140px;}
  .values-head{text-align:center;margin-bottom:80px;}
  .values-head h2{font-family:'Playfair Display',serif;font-size:clamp(36px,5vw,64px);color:var(--white);}
  .values-head h2 em{font-style:italic;color:var(--gold);}
  .values-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;}
  @media(max-width:900px){.values-grid{grid-template-columns:repeat(2,1fr);}}
  .value-card{padding:48px 36px;background:var(--deep);border:1px solid var(--border);text-align:center;}
  .value-num{font-family:'Playfair Display',serif;font-size:64px;color:rgba(201,168,76,0.15);font-weight:900;line-height:1;margin-bottom:16px;}
  .value-card h3{font-family:'Playfair Display',serif;font-size:22px;color:var(--white);margin-bottom:12px;}
  .value-card p{font-size:13px;color:var(--muted);line-height:1.75;}

  footer{padding:80px 48px;border-top:1px solid var(--border);text-align:center;}
  .footer-text{font-size:12px;color:var(--muted);letter-spacing:0.08em;}
  .footer-text span{color:var(--gold);}
`;

const MarinaIllustration = () => (
  <svg viewBox="0 0 500 400" fill="none" width="80%" opacity={0.2}>
    <rect x="50" y="280" width="400" height="8" fill="var(--steel)"/>
    <rect x="80" y="200" width="12" height="80" fill="var(--steel)"/>
    <rect x="200" y="180" width="12" height="100" fill="var(--steel)"/>
    <rect x="320" y="200" width="12" height="80" fill="var(--steel)"/>
    <rect x="410" y="210" width="12" height="70" fill="var(--steel)"/>
    <path d="M100 270 L160 250 L180 270Z" fill="var(--navy)" stroke="var(--steel)" strokeWidth="1.5"/>
    <rect x="130" y="240" width="50" height="30" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
    <path d="M220 265 L290 240 L310 265Z" fill="var(--navy)" stroke="var(--steel)" strokeWidth="1.5"/>
    <rect x="250" y="228" width="60" height="37" fill="var(--deep)" stroke="var(--steel)" strokeWidth="1"/>
    <line x1="280" y1="195" x2="280" y2="228" stroke="var(--gold)" strokeWidth="2"/>
    <path d="M280 197 L305 210 L280 222Z" fill="var(--gold)" opacity="0.7"/>
    <path d="M50 295 Q150 280 250 295 Q350 310 450 295" stroke="var(--horizon)" strokeWidth="1" opacity="0.5"/>
    <path d="M50 305 Q150 290 250 305 Q350 320 450 305" stroke="var(--horizon)" strokeWidth="1" opacity="0.3"/>
  </svg>
);

export default function AboutPage() {
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".about-hero-copy > *", { y: 50, opacity: 0, stagger: 0.2, duration: 1.2, ease: "power4.out" });
      gsap.from(".about-hero-visual-inner", { scale: 1.1, opacity: 0, duration: 2, ease: "expo.out", delay: 0.3 });
      const reveals = gsap.utils.toArray<HTMLElement>(".reveal");
      reveals.forEach(el => {
        gsap.fromTo(el, { y: 50, opacity: 0 }, { scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" }, y: 0, opacity: 1, duration: 1.1, ease: "power3.out" });
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>
      <nav className="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h} className={l === "About" ? "active" : ""}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="about-hero">
        <div className="about-hero-copy">
          <div className="page-hero-label"><div className="label-line" /><span className="label-text">Est. Freeport, 1989</span></div>
          <h1>Our <em>Story</em></h1>
          <p>For over three decades, Port Lucaya Marina has served as the gateway to Grand Bahama's waters — and the home port for every adventure that begins here.</p>
        </div>
        <div className="about-hero-visual">
          <div className="about-hero-visual-inner"><MarinaIllustration /></div>
        </div>
      </section>

      <section className="story-section">
        <div className="story-grid">
          <div className="story-sticky reveal">
            <div className="story-label"><div className="story-label-line" /><span className="story-label-text">History</span></div>
            <h2 className="story-heading">Three decades<br />on the <em>water</em></h2>
            <p className="story-subtext">From a modest fuel dock in 1989 to one of the Caribbean's most recognised yachting destinations — the journey has always been guided by one principle: the sea deserves respect, and so do the people who sail it.</p>
          </div>
          <div className="story-chapters">
            {[
              { year: "1989", title: "The First Slip", body: "Port Lucaya Marina opened with 32 slips and a single fuel dock. The founders' vision was simple: give mariners a clean, safe, hospitable stop on the way to the Exumas." },
              { year: "1997", title: "Port of Entry Status", body: "Designated an official Bahamian Port of Entry, transforming the marina's role from a stopover to a genuine gateway. International traffic tripled within two years." },
              { year: "2006", title: "Full Expansion", body: "The marina grew to its current 106-slip capacity, adding the fuel berth, customs house, and the charter fleet that remains the backbone of our experiences programme." },
              { year: "2018", title: "Recovery & Rebuild", body: "Following Hurricane Dorian's impact on Grand Bahama, Port Lucaya underwent a full infrastructure rebuild — emerging with upgraded electrical, dockage, and guest facilities." },
              { year: "2024", title: "Digital Marina", body: "Partnering with ReefCore to digitise slip reservations, charter bookings, and guest management — making Port Lucaya one of the first fully modern marinas in the Caribbean." },
            ].map((ch, i) => (
              <div key={i} className="story-chapter reveal">
                <span className="story-year">{ch.year}</span>
                <h3>{ch.title}</h3>
                <p>{ch.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="team-section">
        <div className="team-head reveal">
          <h2>The <em>Team</em></h2>
          <p>The people behind Port Lucaya — captains, dockhands, and hosts who have spent their lives on these waters.</p>
        </div>
        <div className="team-grid">
          {[
            { name: "Captain Roy Ferguson", role: "Marina Director", bio: "35 years at sea across the Atlantic and Caribbean. Roy has piloted everything from sport fishers to superyachts, and oversees all charter operations at Port Lucaya.", bg: "linear-gradient(135deg,#0a1f3d,#1a2d40)" },
            { name: "Marcia Thompson", role: "Harbour Master", bio: "Marcia coordinates every vessel arrival and departure at Port Lucaya. A Freeport native, she knows these waters, tides, and currents better than anyone.", bg: "linear-gradient(135deg,#082a35,#0c3545)" },
            { name: "Devon Clarke", role: "Head of Experiences", bio: "Former dive instructor and PADI course director, Devon designs and runs the full experiences programme — snorkel tours, fishing charters, and private cruises.", bg: "linear-gradient(135deg,#14100a,#1e1808)" },
          ].map((t, i) => (
            <div key={i} className="team-card reveal">
              <div className="team-avatar" style={{ background: t.bg }}>
                <svg viewBox="0 0 100 100" fill="none" width="60" opacity={0.2}>
                  <circle cx="50" cy="35" r="22" stroke="var(--gold)" strokeWidth="1.5" fill="none"/>
                  <path d="M10 95 Q10 65 50 65 Q90 65 90 95" stroke="var(--gold)" strokeWidth="1.5" fill="none"/>
                </svg>
              </div>
              <div className="team-body">
                <h3 className="team-name">{t.name}</h3>
                <span className="team-role">{t.role}</span>
                <p className="team-bio">{t.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="values-section">
        <div className="values-head reveal">
          <h2>What We <em>Stand For</em></h2>
        </div>
        <div className="values-grid">
          {[
            { n: "01", title: "Safety First", body: "Every vessel, every departure, every captain meets Bahamian maritime safety standards. Non-negotiable." },
            { n: "02", title: "Local Expertise", body: "We know these waters intimately. Every charter itinerary is designed by people who have fished and sailed here for decades." },
            { n: "03", title: "Environmental Care", body: "We operate with respect for the reef, the ocean, and the Bahamian environment that makes all of this possible." },
            { n: "04", title: "Genuine Hospitality", body: "Not scripted warmth — the real thing. Grand Bahama's culture of welcome runs through everything we do." },
          ].map((v, i) => (
            <div key={i} className="value-card reveal">
              <div className="value-num">{v.n}</div>
              <h3>{v.title}</h3>
              <p>{v.body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
