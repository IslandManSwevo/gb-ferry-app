"use client";

import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const STYLE = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=Outfit:wght@300;400;500;600&display=swap');
  .plm-root{--ink:#080c14;--deep:#0a1628;--navy:#0f2044;--steel:#1e3a5f;--horizon:#2d5a8e;--foam:#e8f4f8;--gold:var(--tenant-primary-color,#c9a84c);--goldlt:#e8c97a;--white:#fafcff;--muted:rgba(232,244,248,0.45);--border:rgba(232,244,248,0.10);background:var(--ink);color:var(--foam);font-family:'Outfit',sans-serif;overflow-x:hidden;min-height:100vh;}
  .plm-root::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");pointer-events:none;z-index:10;opacity:0.6;}
  .plm-root *,.plm-root *::before,.plm-root *::after{box-sizing:border-box;margin:0;padding:0;}
  .reveal{opacity:0;}
  .plm-nav{position:fixed;top:0;left:0;right:0;z-index:100;display:flex;justify-content:space-between;align-items:center;padding:32px 48px;transition:background 0.4s,backdrop-filter 0.4s,padding 0.4s;}
  .plm-nav.scrolled{background:rgba(8,12,20,0.88);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:18px 48px;}
  .nav-logo{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--white);letter-spacing:0.02em;}
  .nav-logo span{color:var(--gold);}
  .nav-links{display:flex;gap:40px;list-style:none;}
  .nav-links a{font-size:12px;color:var(--muted);text-decoration:none;letter-spacing:0.14em;text-transform:uppercase;transition:color 0.3s;}
  .nav-links a:hover,.nav-links a.active{color:var(--gold);}
  .nav-cta{background:transparent;border:1px solid var(--gold);color:var(--gold);font-family:'Outfit',sans-serif;font-size:11px;font-weight:500;letter-spacing:0.12em;text-transform:uppercase;padding:12px 28px;cursor:pointer;transition:all 0.3s;}
  .nav-cta:hover{background:var(--gold);color:var(--ink);}

  .page-hero{padding:180px 48px 100px;background:linear-gradient(160deg,var(--deep) 0%,var(--ink) 60%);border-bottom:1px solid var(--border);}
  .page-hero-label{display:flex;align-items:center;gap:16px;margin-bottom:28px;}
  .label-line{width:48px;height:1px;background:var(--gold);}
  .label-text{font-size:11px;font-weight:500;color:var(--gold);letter-spacing:0.22em;text-transform:uppercase;}
  .page-hero h1{font-family:'Playfair Display',serif;font-size:clamp(52px,8vw,96px);font-weight:900;color:var(--white);line-height:0.9;letter-spacing:-0.02em;}
  .page-hero h1 em{font-style:italic;color:var(--gold);font-weight:400;}
  .page-hero p{font-size:18px;font-weight:300;color:var(--muted);line-height:1.7;max-width:560px;margin-top:28px;}

  /* TOGGLE */
  .pricing-section{padding:100px 48px 160px;}
  .pricing-toggle-wrap{display:flex;align-items:center;justify-content:center;gap:20px;margin-bottom:80px;}
  .toggle-label{font-size:13px;text-transform:uppercase;letter-spacing:0.14em;color:var(--muted);}
  .toggle-label.active{color:var(--foam);}
  .toggle-track{width:52px;height:28px;background:rgba(255,255,255,0.1);border:1px solid var(--border);border-radius:14px;position:relative;cursor:pointer;transition:background 0.3s;}
  .toggle-track.on{background:rgba(201,168,76,0.2);border-color:var(--gold);}
  .toggle-thumb{position:absolute;top:3px;left:3px;width:20px;height:20px;border-radius:50%;background:var(--muted);transition:transform 0.3s,background 0.3s;}
  .toggle-track.on .toggle-thumb{transform:translateX(24px);background:var(--gold);}
  .save-badge{font-size:10px;text-transform:uppercase;letter-spacing:0.12em;padding:4px 10px;background:rgba(201,168,76,0.15);color:var(--gold);border:1px solid rgba(201,168,76,0.3);}

  /* SLIP RATES */
  .pricing-category{margin-bottom:80px;}
  .pricing-cat-head{margin-bottom:40px;}
  .pricing-cat-head h2{font-family:'Playfair Display',serif;font-size:clamp(28px,4vw,48px);color:var(--white);}
  .pricing-cat-head h2 em{font-style:italic;color:var(--gold);}
  .pricing-cat-head p{font-size:14px;color:var(--muted);margin-top:12px;line-height:1.7;}
  
  .rate-table{width:100%;border-collapse:collapse;border:1px solid var(--border);}
  .rate-table th{font-size:10px;text-transform:uppercase;letter-spacing:0.16em;color:var(--gold);text-align:left;padding:16px 24px;background:var(--deep);border-bottom:1px solid var(--border);font-weight:500;}
  .rate-table td{padding:20px 24px;border-bottom:1px solid var(--border);font-size:14px;color:var(--foam);}
  .rate-table tr:last-child td{border-bottom:none;}
  .rate-table tr:hover td{background:rgba(255,255,255,0.02);}
  .rate-price{font-family:'Playfair Display',serif;font-size:22px;color:var(--gold);font-weight:700;}
  .rate-note{font-size:12px;color:var(--muted);margin-top:4px;}

  /* CHARTER TIERS */
  .charter-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;}
  @media(max-width:900px){.charter-grid{grid-template-columns:1fr;}}
  .charter-card{background:var(--deep);border:1px solid var(--border);padding:56px 48px;position:relative;transition:border-color 0.4s;}
  .charter-card.featured{border-color:var(--gold);background:#0d1a2d;}
  .charter-card.featured::before{content:'Most Popular';position:absolute;top:-1px;left:50%;transform:translateX(-50%);background:var(--gold);color:var(--ink);font-size:10px;font-weight:600;letter-spacing:0.14em;text-transform:uppercase;padding:6px 16px;}
  .charter-tier{font-size:10px;color:var(--gold);text-transform:uppercase;letter-spacing:0.2em;margin-bottom:20px;display:block;}
  .charter-name{font-family:'Playfair Display',serif;font-size:36px;color:var(--white);margin-bottom:8px;}
  .charter-desc{font-size:14px;color:var(--muted);line-height:1.7;margin-bottom:36px;}
  .charter-price-wrap{margin-bottom:40px;padding-bottom:40px;border-bottom:1px solid var(--border);}
  .charter-price{font-family:'Playfair Display',serif;font-size:52px;color:var(--gold);font-weight:700;line-height:1;}
  .charter-price sup{font-size:24px;vertical-align:super;}
  .charter-price sub{font-size:16px;color:var(--muted);}
  .charter-features{list-style:none;display:flex;flex-direction:column;gap:14px;margin-bottom:40px;}
  .charter-features li{display:flex;align-items:flex-start;gap:12px;font-size:14px;color:var(--muted);}
  .feature-check{color:var(--gold);font-size:16px;flex-shrink:0;margin-top:1px;}
  .btn-primary{background:var(--gold);color:var(--ink);border:none;padding:18px 40px;font-size:12px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;}
  .btn-primary:hover{background:var(--goldlt);transform:translateY(-2px);box-shadow:0 8px 24px rgba(201,168,76,0.25);}
  .btn-outline{background:transparent;border:1px solid var(--border);color:var(--foam);padding:18px 40px;font-size:12px;letter-spacing:0.12em;text-transform:uppercase;cursor:pointer;transition:all 0.3s;width:100%;}
  .btn-outline:hover{border-color:var(--gold);color:var(--gold);}

  /* FAQ */
  .faq-section{padding:100px 48px;background:#060a14;border-top:1px solid var(--border);}
  .faq-head{text-align:center;margin-bottom:60px;}
  .faq-head h2{font-family:'Playfair Display',serif;font-size:clamp(32px,5vw,56px);color:var(--white);}
  .faq-head h2 em{font-style:italic;color:var(--gold);}
  .faq-list{max-width:760px;margin:0 auto;display:flex;flex-direction:column;gap:2px;}
  .faq-item{background:var(--deep);border:1px solid var(--border);overflow:hidden;}
  .faq-q{width:100%;background:none;border:none;padding:28px 32px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;font-family:'Outfit',sans-serif;font-size:16px;color:var(--foam);text-align:left;transition:color 0.3s;}
  .faq-q:hover{color:var(--gold);}
  .faq-icon{color:var(--gold);font-size:20px;flex-shrink:0;transition:transform 0.3s;}
  .faq-a{padding:0 32px 24px;font-size:14px;color:var(--muted);line-height:1.8;}

  footer{padding:80px 48px;border-top:1px solid var(--border);text-align:center;}
  .footer-text{font-size:12px;color:var(--muted);letter-spacing:0.08em;}
  .footer-text span{color:var(--gold);}
`;

const slipRates = [
  { loa: "Up to 30 ft", daily: "$2.50/ft", weekly: "$2.00/ft", monthly: "$1.50/ft" },
  { loa: "31 – 50 ft", daily: "$3.00/ft", weekly: "$2.50/ft", monthly: "$2.00/ft" },
  { loa: "51 – 80 ft", daily: "$3.50/ft", weekly: "$3.00/ft", monthly: "$2.50/ft" },
  { loa: "81 – 120 ft", daily: "$4.00/ft", weekly: "$3.50/ft", monthly: "$3.00/ft" },
  { loa: "121 – 190 ft", daily: "By quote", weekly: "By quote", monthly: "By quote" },
];

const charters = [
  {
    tier: "Half Day",
    name: "The Reef",
    desc: "A 4-hour private charter. Fishing, snorkelling, or cruising — your pick.",
    price: 450,
    features: ["Up to 6 guests", "Licensed captain", "All tackle & equipment", "Fuel included", "Soft drinks & ice"],
    featured: false,
  },
  {
    tier: "Full Day",
    name: "The Deep",
    desc: "8 hours, open ocean access. The flagship charter experience.",
    price: 950,
    features: ["Up to 8 guests", "Captain + first mate", "Full tackle rig", "Catering available", "Fuel & bait included", "Photography available"],
    featured: true,
  },
  {
    tier: "Overnight",
    name: "The Horizon",
    desc: "Multi-day voyages to the Exumas, Abacos, or beyond. Fully crewed.",
    price: 2200,
    features: ["Up to 10 guests", "Full crew", "All meals included", "Bespoke itinerary", "Equipment & fuel", "Concierge planning"],
    featured: false,
  },
];

const faqs = [
  { q: "What is included in the slip rate?", a: "Slip rates include shore power (50/200A), Wi-Fi, fresh water, and access to all marina facilities including showers. Fuel is available at the dock at current market prices." },
  { q: "Do you accommodate superyachts?", a: "Yes. Port Lucaya Marina accepts vessels up to 190 ft LOA with deep draft capability. For vessels over 120 ft, please contact us directly for a custom rate and slip assignment." },
  { q: "Is Port Lucaya an official Port of Entry?", a: "Yes. We are an official Bahamian Port of Entry. Our dock staff can facilitate customs and immigration clearance for vessels arriving from international waters." },
  { q: "What payment methods do you accept?", a: "We accept USD cash, major credit cards, PayPal, and Bahamian Sand Dollar (CBDC). A 50% deposit is required to secure charter bookings." },
  { q: "Are charter prices all-inclusive?", a: "Charter prices include captain, crew, fuel, and listed equipment. Food, beverages beyond soft drinks, fishing licences, and optional add-ons are available at additional cost." },
];

export default function PricingPage() {
  const rootRef = useRef<HTMLDivElement>(null);
  const [annual, setAnnual] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".page-hero h1,.page-hero p,.page-hero-label", { y: 50, opacity: 0, stagger: 0.15, duration: 1.2, ease: "power4.out" });
      const reveals = gsap.utils.toArray<HTMLElement>(".reveal");
      reveals.forEach(el => {
        gsap.fromTo(el, { y: 50, opacity: 0 }, { scrollTrigger: { trigger: el, start: "top 88%", toggleActions: "play none none none" }, y: 0, opacity: 1, duration: 1.1, ease: "power3.out" });
      });
    }, rootRef);
    return () => ctx.revert();
  }, []);

  return (
    <div className="plm-root" ref={rootRef}>
      <style>{STYLE}</style>

      <nav className="plm-nav">
        <div className="nav-logo">PORT LUCAYA<span>.</span></div>
        <ul className="nav-links">
          {[["Experiences", "/experiences"], ["The Fleet", "/fleet"], ["Gallery", "/gallery"], ["Pricing", "/pricing"], ["About", "/about"]].map(([l, h]) => (
            <li key={l}><a href={h} className={l === "Pricing" ? "active" : ""}>{l}</a></li>
          ))}
        </ul>
        <button className="nav-cta" onClick={() => window.location.href = "/book"}>Book a Slip</button>
      </nav>

      <section className="page-hero">
        <div className="page-hero-label"><div className="label-line" /><span className="label-text">Transparent Rates</span></div>
        <h1>Rates &amp; <em>Pricing</em></h1>
        <p>Slip rates, charter packages, and experience pricing — all in one place. No hidden fees. No surprises at checkout.</p>
      </section>

      <section className="pricing-section">
        {/* Slip Rates */}
        <div className="pricing-category reveal">
          <div className="pricing-cat-head">
            <h2>Slip <em>Rates</em></h2>
            <p>All rates are per foot of LOA. Power (50/200A), water, and Wi-Fi included. Minimum 2-night stay during peak season.</p>
          </div>
          <table className="rate-table">
            <thead>
              <tr>
                <th>Vessel Length</th>
                <th>Daily Rate</th>
                <th>Weekly Rate</th>
                <th>Monthly Rate</th>
              </tr>
            </thead>
            <tbody>
              {slipRates.map((r) => (
                <tr key={r.loa}>
                  <td>{r.loa}</td>
                  <td><span className="rate-price">{r.daily}</span></td>
                  <td><span className="rate-price">{r.weekly}</span></td>
                  <td><span className="rate-price">{r.monthly}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Charter Packages */}
        <div className="pricing-category" style={{ marginTop: 100 }}>
          <div className="pricing-cat-head reveal">
            <h2>Charter <em>Packages</em></h2>
            <p>Fully crewed private charters from Port Lucaya. Pricing is per charter, not per person. Deposit required at booking.</p>
          </div>
          <div className="charter-grid">
            {charters.map((c, i) => (
              <div key={i} className={`charter-card reveal${c.featured ? " featured" : ""}`}>
                <span className="charter-tier">{c.tier}</span>
                <h3 className="charter-name">{c.name}</h3>
                <p className="charter-desc">{c.desc}</p>
                <div className="charter-price-wrap">
                  <div className="charter-price">
                    <sup>$</sup>{c.price.toLocaleString()}<sub> USD</sub>
                  </div>
                </div>
                <ul className="charter-features">
                  {c.features.map((f) => (
                    <li key={f}><span className="feature-check">✦</span>{f}</li>
                  ))}
                </ul>
                {c.featured
                  ? <button className="btn-primary" onClick={() => window.location.href = "/book"}>Reserve Now</button>
                  : <button className="btn-outline" onClick={() => window.location.href = "/book"}>Enquire</button>
                }
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="faq-head reveal">
          <h2>Common <em>Questions</em></h2>
        </div>
        <div className="faq-list">
          {faqs.map((faq, i) => (
            <div key={i} className="faq-item reveal">
              <button className="faq-q" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                {faq.q}
                <span className="faq-icon" style={{ transform: openFaq === i ? "rotate(45deg)" : "none" }}>+</span>
              </button>
              {openFaq === i && <div className="faq-a">{faq.a}</div>}
            </div>
          ))}
        </div>
      </section>

      <footer>
        <p className="footer-text">© 2026 PORT LUCAYA MARINA · FREEPORT, THE BAHAMAS · POWERED BY <span>REEFCORE</span></p>
      </footer>
    </div>
  );
}
